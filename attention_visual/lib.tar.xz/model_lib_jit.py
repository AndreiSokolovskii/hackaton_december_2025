import torch
import torch_geometric
import math
from itertools import product
from model_lib import PositionalEncoding, EdgeUpdateBlock
from torch_geometric.nn import radius_graph, TransformerConv
from torch_geometric.nn.inits import reset, ones, zeros
from torch_geometric.nn.resolver import activation_resolver
from torch_geometric.nn.conv import MessagePassing
from typing import Optional, Any, Dict, Optional, Tuple, List
from torch_scatter import scatter_min, scatter_max, scatter_sum
from torch_geometric.utils import get_self_loop_attr, is_torch_sparse_tensor, to_edge_index, to_torch_coo_tensor, to_torch_csr_tensor, scatter



from torch_geometric.typing import Adj

class CudaGraphRunner:
    def __init__(self, model_frozen,dtype=torch.bfloat16):
        self.model = model_frozen
        self._cache = {}  # ключ по форме -> (graph, static_tensors, static_output)
        self.dtype = dtype

    def _capture(self, x, y_masked, edge_index, edge_attr, batch, mask, batch_size, max_num_nodes):
        static_x = x.clone()
        static_y = y_masked.clone()
        static_edge_index = edge_index.clone()
        static_edge_attr = edge_attr.clone()
        static_batch = batch.clone()
        static_mask = mask.clone()

        # warm-up на side stream - обязательно, иначе capture может подхватить
        # неинициализированное состояние (например, cuDNN benchmark/autotune)
        s = torch.cuda.Stream()
        s.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(s):
            with torch.no_grad(), torch.autocast(device_type='cuda', dtype=self.dtype):
                for _ in range(3):
                    _ = self.model(static_x, static_y, static_edge_index,
                                static_edge_attr, static_batch, static_mask, batch_size, max_num_nodes)
        torch.cuda.current_stream().wait_stream(s)
        torch.cuda.synchronize()

        g = torch.cuda.CUDAGraph()
        with torch.cuda.graph(g):
            with torch.no_grad(), torch.autocast(device_type='cuda', dtype=self.dtype):
                static_logits = self.model(static_x, static_y, static_edge_index,
                                        static_edge_attr, static_batch, static_mask, batch_size, max_num_nodes)

        return {
            "graph": g,
            "static_x": static_x,
            "static_y": static_y,
            "static_edge_index": static_edge_index,
            "static_edge_attr": static_edge_attr,
            "static_batch": static_batch,
            "static_mask": static_mask,
            "static_logits": static_logits,
        }

    def run(self, x, y_masked, edge_index, edge_attr, batch, mask, batch_size, max_num_nodes):
        # ключ кэша - форма входов (число узлов, число рёбер, batch_size)
        key = (x.shape, edge_index.shape, batch_size)

        if key not in self._cache:
            self._cache[key] = self._capture(x, y_masked, edge_index, edge_attr, batch, mask, batch_size, max_num_nodes)

        entry = self._cache[key]

        # копируем новые данные в статические буферы (адреса памяти не меняются - это и есть весь смысл)
        entry["static_x"].copy_(x)
        entry["static_y"].copy_(y_masked)
        entry["static_edge_index"].copy_(edge_index)
        entry["static_edge_attr"].copy_(edge_attr)
        entry["static_batch"].copy_(batch)
        entry["static_mask"].copy_(mask)

        entry["graph"].replay()

        return entry["static_logits"]


def _orthogonal_matrix(dim: int) -> torch.Tensor:
    r"""Get an orthogonal matrix by applying QR decomposition."""
    # Random matrix from normal distribution
    mat = torch.randn((dim, dim))
    # QR decomposition to two orthogonal matrices
    q, _ = torch.linalg.qr(mat.cpu(), mode='reduced')
    return q.t()


def orthogonal_matrix(num_rows: int, num_cols: int) -> torch.Tensor:
    r"""Generate an orthogonal matrix with `num_rows` rows
    and `num_cols` columns.
    """
    num_full_blocks = int(num_rows / num_cols)
    blocks = []
    for _ in range(num_full_blocks):
        q = _orthogonal_matrix(num_cols)
        blocks.append(q)
    remain_rows = num_rows - num_full_blocks * num_cols
    if remain_rows > 0:
        q = _orthogonal_matrix(num_cols)
        blocks.append(q[:remain_rows])
    mat = torch.cat(blocks)

    return mat


def linear_attention(q: torch.Tensor, k: torch.Tensor, v: torch.Tensor) -> torch.Tensor:
    r"""Efficient attention mechanism from the
    `"Rethinking Attention with Performers"
    <https://arxiv.org/abs/2009.14794>`_ paper.

    .. math::
        \mathbf{\hat{D}}^{-1}(\mathbf{Q}'((\mathbf{K}')^{\top} \mathbf{V}))

    """
    D_inv = 1.0 / (q @ k.sum(dim=-2).unsqueeze(-1))
    kv = k.transpose(-2, -1) @ v
    qkv = q @ kv
    out = torch.einsum('...L,...Ld->...Ld', D_inv.squeeze(-1), qkv)
    return out


def generalized_kernel(
        x: torch.Tensor,
        mat: torch.Tensor,
        epsilon: float = 0.001,
) -> torch.Tensor:
    # kernel = torch.nn.ReLU()
    batch_size, num_heads = x.size()[:2]
    projection = mat.t().expand(batch_size, num_heads, -1, -1)
    x = x @ projection
    # out = kernel(x) + epsilon
    out = torch.nn.functional.relu(x) + epsilon
    return out


class PerformerProjection(torch.nn.Module):
    r"""The fast attention that uses a projection matrix
    from the `"Rethinking Attention with Performers"
    <https://arxiv.org/abs/2009.14794>`_ paper. This class
    projects :math:`\mathbf{Q}` and :math:`\mathbf{K}` matrices
    with specified kernel.

    Args:
        num_cols (int): Projection matrix number of columns.
        kernel (Callable, optional): Kernels for generalized attention.
            If not specified, `ReLU` kernel will be used.
            (default: :obj:`torch.nn.ReLU()`)
    """
    def __init__(self, 
                 num_cols: int, 
                 ):
        super().__init__()

        num_rows = int(num_cols * math.log(num_cols))
        self.num_rows = num_rows
        self.num_cols = num_cols
        projection_matrix = orthogonal_matrix(self.num_rows, self.num_cols)
        self.register_buffer('projection_matrix', projection_matrix)

    def forward(self, q: torch.Tensor, k: torch.Tensor, v: torch.Tensor) -> torch.Tensor:
        q = generalized_kernel(x=q, 
                               mat=self.projection_matrix, 
                               )
        k = generalized_kernel(x=k, 
                               mat=self.projection_matrix, 
                               )
        out = linear_attention(q=q, k=k, v=v)
        return out


class PerformerAttention(torch.nn.Module):
    r"""The linear scaled attention mechanism from the
    `"Rethinking Attention with Performers"
    <https://arxiv.org/abs/2009.14794>`_ paper.

    Args:
        channels (int): Size of each input sample.
        heads (int, optional): Number of parallel attention heads.
        head_channels (int, optional): Size of each attention head.
            (default: :obj:`64.`)
        kernel (Callable, optional): Kernels for generalized attention.
            If not specified, `ReLU` kernel will be used.
            (default: :obj:`torch.nn.ReLU()`)
        qkv_bias (bool, optional): If specified, add bias to query, key
            and value in the self attention. (default: :obj:`False`)
        attn_out_bias (bool, optional): If specified, add bias to the
            attention output. (default: :obj:`True`)
        dropout (float, optional): Dropout probability of the final
            attention output. (default: :obj:`0.0`)

    """
    def __init__(
        self,
        channels: int,
        heads: int,
        head_channels: int = 64,
        # kernel: torch.nn.Module = torch.nn.ReLU(),
        qkv_bias: bool = False,
        attn_out_bias: bool = True,
        dropout: float = 0.0,
    ):
        super().__init__()
        assert channels % heads == 0
        if head_channels is None:
            head_channels = channels // heads

        self.heads = heads
        self.head_channels = head_channels
        
        self.fast_attn = PerformerProjection(
                                            num_cols=head_channels, 
                                            # kernel=self.kernel,
                                            )

        inner_channels = head_channels * heads
        self.q = torch.nn.Linear(channels, inner_channels, bias=qkv_bias)
        self.k = torch.nn.Linear(channels, inner_channels, bias=qkv_bias)
        self.v = torch.nn.Linear(channels, inner_channels, bias=qkv_bias)
        self.attn_out = torch.nn.Linear(inner_channels, channels,
                                        bias=attn_out_bias)
        self.dropout = torch.nn.Dropout(dropout)

    def forward(self, x: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        r"""Forward pass.

        Args:
            x (torch.Tensor): Node feature tensor
                :math:`\mathbf{X} \in \mathbb{R}^{B \times N \times F}`, with
                batch-size :math:`B`, (maximum) number of nodes :math:`N` for
                each graph, and feature dimension :math:`F`.
            mask (torch.Tensor, optional): Mask matrix
                :math:`\mathbf{M} \in {\{ 0, 1 \}}^{B \times N}` indicating
                the valid nodes for each graph. (default: :obj:`None`)
        """
        # B, N, *_ = x.shape
        B = x.shape[0]
        N = x.shape[1]
        q, k, v = self.q(x), self.k(x), self.v(x)
        
        q = q.reshape(B, N, self.heads, self.head_channels).permute(0, 2, 1, 3).contiguous()
        k = k.reshape(B, N, self.heads, self.head_channels).permute(0, 2, 1, 3).contiguous()
        v = v.reshape(B, N, self.heads, self.head_channels).permute(0, 2, 1, 3).contiguous()
        
        mask = mask[:, None, :, None]
        v.masked_fill_(~mask, 0.)
        q.masked_fill_(~mask, 0.)
        k.masked_fill_(~mask, 0.)
        out = self.fast_attn(q=q, k=k, v=v)
        
        out = out.permute(0, 2, 1, 3).contiguous().reshape(B, N, -1)
        out = self.attn_out(out)
        out = self.dropout(out)
        return out

    @torch.no_grad()
    def redraw_projection_matrix(self):
        r"""As described in the paper, periodically redraw
        examples to improve overall approximation of attention.
        """
        num_rows = self.fast_attn.num_rows
        num_cols = self.fast_attn.num_cols
        projection_matrix = orthogonal_matrix(num_rows, num_cols)
        self.fast_attn.projection_matrix.copy_(projection_matrix)
        del projection_matrix

    def _reset_parameters(self):
        self.q.reset_parameters()
        self.k.reset_parameters()
        self.v.reset_parameters()
        self.attn_out.reset_parameters()
        self.redraw_projection_matrix()

    def __repr__(self) -> str:
        return (f'{self.__class__.__name__}('
                f'heads={self.heads}, '
                f'head_channels={self.head_channels} '
                f'kernel={self.kernel})')


class GraphNorm(torch.nn.Module):
    def __init__(self, in_channels: int, eps: float = 1e-5,
                 device: Optional[torch.device] = None):
        super().__init__()

        self.in_channels = in_channels
        self.eps = eps

        self.weight = torch.nn.Parameter(
            torch.empty(in_channels, device=device))
        self.bias = torch.nn.Parameter(torch.empty(in_channels, device=device))
        self.mean_scale = torch.nn.Parameter(
            torch.empty(in_channels, device=device))

        self.reset_parameters()

    def reset_parameters(self):
        r"""Resets all learnable parameters of the module."""
        ones(self.weight)
        zeros(self.bias)
        ones(self.mean_scale)

    def forward(self, x: torch.Tensor, batch: torch.Tensor,
                batch_size: int, valid_mask: torch.Tensor) -> torch.Tensor:
    
        valid_mask = valid_mask.to(x.dtype).unsqueeze(-1)  # (N, 1), float 0./1., БЕЗ индексации по x

        # считаем сумму и count по валидным узлам через маскирование, форма x не меняется
        x_masked = x * valid_mask
        sum_per_graph = torch.zeros(batch_size, x.size(-1), device=x.device, dtype=x.dtype)
        sum_per_graph = sum_per_graph.scatter_add(
            0, batch.view(-1, 1).expand_as(x), x_masked
        )
        count_per_graph = torch.zeros(batch_size, 1, device=x.device, dtype=x.dtype)
        count_per_graph = count_per_graph.scatter_add(
            0, batch.view(-1, 1), valid_mask
        ).clamp(min=1.0)

        mean = sum_per_graph / count_per_graph  # (batch_size, C)

        centered = x - mean.index_select(0, batch) * self.mean_scale
        centered_masked = centered * valid_mask

        sq_sum_per_graph = torch.zeros(batch_size, x.size(-1), device=x.device, dtype=x.dtype)
        sq_sum_per_graph = sq_sum_per_graph.scatter_add(
            0, batch.view(-1, 1).expand_as(x), centered_masked.pow(2)
        )
        var = sq_sum_per_graph / count_per_graph

        std_full = (var + self.eps).sqrt().index_select(0, batch)  # (N, C)
        mean_full = mean.index_select(0, batch)

        out_full = x - mean_full * self.mean_scale
        out_full = self.weight * out_full / std_full + self.bias

        # финальный выбор через torch.where вместо boolean-индексации - форма не меняется
        valid_mask_bool = valid_mask.to(torch.bool)
        out = torch.where(valid_mask_bool, out_full, x)

        return out

    def __repr__(self):
        return f'{self.__class__.__name__}({self.in_channels})'
def _cumsum(x: torch.Tensor, dim: int = 0) -> torch.Tensor:
    size = x.size()[:dim] + (x.size(dim) + 1,) + x.size()[dim + 1:]
    out = x.new_zeros(size)
    out.narrow(dim, 1, x.size(dim)).copy_(torch.cumsum(x, dim=dim))
    return out

def to_dense_batch_safe(
    x: torch.Tensor,
    batch: torch.Tensor,
    fill_value: float = 0.0,
    max_num_nodes: Optional[int] = None,
    batch_size: Optional[int] = None,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    assert batch_size is not None
    assert max_num_nodes is not None

    ones = torch.ones_like(batch, dtype=x.dtype)
    num_nodes = torch.zeros(batch_size, device=x.device, dtype=x.dtype)
    num_nodes = num_nodes.scatter_add(0, batch, ones)
    cum_nodes = _cumsum(num_nodes).to(torch.long)

    tmp = torch.arange(batch.size(0), device=x.device) - cum_nodes[batch]
    idx = tmp + (batch * max_num_nodes)   # (N,) -- позиция каждого разреженного узла в плоском плотном буфере

    size = [batch_size * max_num_nodes] + list(x.size())[1:]
    out = torch.full(size, fill_value, device=x.device, dtype=x.dtype)
    out = out.index_copy(0, idx, x)
    out = out.view([batch_size, max_num_nodes] + list(x.size())[1:])

    mask = torch.zeros(batch_size * max_num_nodes, dtype=torch.bool, device=x.device)
    mask = mask.index_fill(0, idx, True)
    mask = mask.view(batch_size, max_num_nodes)

    return out, mask, idx
class GPSConv_w_Performer(torch.nn.Module):
    def __init__(
        self,
        channels: int,
        conv: Optional[MessagePassing],
        heads: int = 1,
        dropout: float = 0.0,
        act: str = 'relu',
        act_kwargs: Optional[Dict[str, Any]] = None,
        norm_kwargs: Optional[Dict[str, Any]] = None,
        attn_kwargs: Optional[Dict[str, Any]] = None,
    ):
        super().__init__()

        self.channels = channels
        self.conv = conv
        self.heads = heads
        self.dropout = dropout

        attn_kwargs = attn_kwargs or {}
        
        self.attn = PerformerAttention(
                channels=channels,
                heads=heads,
                **attn_kwargs,
            )

        self.mlp = torch.nn.Sequential(
            torch.nn.Linear(channels, channels * 2),
            activation_resolver(act, **(act_kwargs or {})),
            torch.nn.Dropout(dropout),
            torch.nn.Linear(channels * 2, channels),
            torch.nn.Dropout(dropout),
        )

        norm_kwargs = norm_kwargs or {}
        self.norm1 = GraphNorm(channels)
        self.norm2 = GraphNorm(channels)
        self.norm3 = GraphNorm(channels)

    def reset_parameters(self) -> None:
        r"""Resets all learnable parameters of the module."""
        if self.conv is not None:
            self.conv.reset_parameters()
        self.attn._reset_parameters()
        reset(self.mlp)
        if self.norm1 is not None:
            self.norm1.reset_parameters()
        if self.norm2 is not None:
            self.norm2.reset_parameters()
        if self.norm3 is not None:
            self.norm3.reset_parameters()

    def forward(
        self,
        x: torch.Tensor,
        edge_index: Adj,
        valid_mask:torch.Tensor,
        batch: torch.Tensor,
        batch_size: int,
        max_num_nodes: int,
        edge_attr: torch.Tensor,
        
    ) -> torch.Tensor:
        r"""Runs the forward pass of the module."""
        hs: List[torch.Tensor] = []
        
        h = self.conv(x=x, edge_index=edge_index, edge_attr=edge_attr)
        h = torch.nn.functional.dropout(h, p=self.dropout, training=self.training)
        h = h + x        
        h = self.norm1(x=h, batch=batch, valid_mask=valid_mask, batch_size=batch_size)

        hs.append(h)


        h, mask, idx = to_dense_batch_safe(x=x, batch=batch, batch_size=batch_size, max_num_nodes=max_num_nodes)
        dense_valid, _, _ = to_dense_batch_safe(x=valid_mask.to(torch.float), batch=batch, batch_size=batch_size, max_num_nodes=max_num_nodes)
        dense_valid = dense_valid.to(torch.bool)
        attend_mask = mask & dense_valid 

        h = self.attn(h, mask=attend_mask)

        
        h_flat = h.reshape(batch_size * max_num_nodes, -1)   # (B*max_num_nodes, C), форма статична
        h = h_flat.index_select(0, idx) 
        h = torch.nn.functional.dropout(h, p=self.dropout, training=self.training)
        h = h + x  # Residual connection.
        
        h = self.norm2(x=h, batch=batch, valid_mask=valid_mask, batch_size=batch_size)
        
        hs.append(h)
        out = torch.stack(hs).sum(dim=0)
        out = out + self.mlp(out)
        
        out = self.norm3(x=out, batch=batch, valid_mask=valid_mask, batch_size=batch_size)

        return out

    def __repr__(self) -> str:
        return (f'{self.__class__.__name__}({self.channels}, '
                f'conv={self.conv}, heads={self.heads}, '
                f'attn_type={self.attn_type})')






class featurizer_for_jit(torch.nn.Module):
    def __init__(self, backbone_noise: float = 0.0):
        super().__init__()
        self.channels = 128
        self.radius_for_graph = 9.5
        self.max_num_neighbors = 148
        self.pre_pe_dim = 10
        self.mask_token = torch.tensor(21)
        self.num_positional_embedding = 16
        self.pe_norm_rPa = torch.nn.BatchNorm1d(self.pre_pe_dim)
        self.pe_lin_rPa = torch.nn.Linear(self.pre_pe_dim, self.channels)
        self.augment_eps = backbone_noise
        self.embedding = PositionalEncoding(self.num_positional_embedding)
        self.edge_dim = 600
        self.edge_emb_input_proj = torch.nn.Sequential(
                    torch.nn.Linear(self.edge_dim+self.num_positional_embedding, self.channels),
                    torch.nn.LayerNorm(self.channels),
                    torch.nn.Linear(self.channels, self.channels),
                )


    def _get_pe(self, out: torch.Tensor, N:int, loop_index:Optional[torch.Tensor]=None) -> torch.Tensor:
            if is_torch_sparse_tensor(out):
                return get_self_loop_attr(*to_edge_index(out), num_nodes=N)
            return out[loop_index, loop_index]
    def _get_rwpe(self, 
                  edge_index: torch.Tensor, 
                  walk_length:int =10)-> torch.Tensor:
        row, col = edge_index[0], edge_index[1]
        N = int(edge_index.max()+1)
        num_edges = edge_index.shape[1]
        value = torch.ones(num_edges, device=row.device)
        value = scatter(value, row, dim_size=N, reduce='sum').clamp(min=1)[row]
        value = 1.0 / value
        loop_index = torch.arange(N, device=row.device)
        if N <= 2_500:  # Dense code path for faster computation:
            adj = torch.zeros((N, N), device=row.device)
            adj[row, col] = value
        elif torch_geometric.typing.NO_MKL:  # pragma: no cover
            adj = to_torch_coo_tensor(edge_index, value, size=(N, N))
            
        else:
            adj = to_torch_csr_tensor(edge_index, value, size=(N, N))

        out = adj
        pe_list = [self._get_pe(out=out, N=N, loop_index=loop_index)]
        for _ in range(walk_length - 1):
            out = out @ adj
            pe_list.append(self._get_pe(out=out, N=N, loop_index=loop_index))

        pe = torch.stack(pe_list, dim=-1)
        return pe
    def _fourier_encode_dist(self, 
                             x: torch.Tensor, 
                             num_encodings:int = 4, 
                             include_self:bool = False)-> torch.Tensor:
        x = x.unsqueeze(-1)
        device, dtype, orig_x = x.device, x.dtype, x
        scales = 2 ** torch.arange(num_encodings, device = device, dtype = dtype)
        x = x / scales
        x = torch.cat([x.sin(), x.cos()], dim=-1)
        x = torch.cat((x, orig_x), dim = -1) if include_self else x
        return x
    def _rbf_encode_dist(self, 
                         distances: torch.Tensor, 
                         num_rbf:int = 16, 
                         min_distance:float = 2.0, 
                         max_distance:float = 32.0)-> torch.Tensor:
        rbf_centers = torch.linspace(min_distance, max_distance, num_rbf, device=distances.device)
        rbf_widths = (max_distance / num_rbf) * torch.ones_like(rbf_centers)
        rbf_activation = torch.exp(-((distances.unsqueeze(-1) - rbf_centers) ** 2) / (2 * rbf_widths**2))
        return rbf_activation
    def _featurize(
                    self,
                    x: torch.Tensor,
                    mask: torch.Tensor,
                    batch: torch.Tensor,
                ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        N, Ca, C, O = (x[:, i, :] for i in range(4))  # noqa: E741
        b = Ca - N
        c = C - Ca
        a = torch.cross(b, c, dim=-1)
        Cb = -0.58273431 * a + 0.56802827 * b - 0.54067466 * c + Ca

        valid_mask = mask.to(torch.bool)
        valid_Ca = Ca[valid_mask]
        valid_batch = batch[valid_mask]

        edge_index = radius_graph(valid_Ca, r=self.radius_for_graph, max_num_neighbors=self.max_num_neighbors,
                               batch=valid_batch, loop=True)
        rwpe = self._get_rwpe(edge_index=edge_index)
        row, col = edge_index[0], edge_index[1]
        original_indices = torch.arange(Ca.size(0), device=x.device)[valid_mask]
        rwpe_full = torch.zeros(Ca.size(0),self.pre_pe_dim, device=Ca.device,dtype=rwpe.dtype,)
        rwpe_full[original_indices] = rwpe 

        edge_index_original = torch.stack([original_indices[row], original_indices[col]], dim=0)
        row, col = edge_index_original[0], edge_index_original[1]
        rbf_all = []
        for A, B in list(product([N, Ca, C, O, Cb], repeat=2)):
                tmp = torch.square(A[row] - B[col])
                distances = torch.sqrt(torch.sum(tmp, 1) + 1e-6)
                rbf_en = self._rbf_encode_dist(distances)
                f_en = self._fourier_encode_dist(tmp.sum(-1), include_self=False)
                rbf_en = torch.cat([rbf_en, f_en], dim=1)
                rbf_all.append(rbf_en)

        return edge_index_original, torch.cat(rbf_all, dim=-1), rwpe_full
    def forward(self,
                pos: torch.Tensor,
                chain_seq_label: torch.Tensor,
                mask: torch.Tensor,
                chain_mask_all: torch.Tensor,
                residue_idx: torch.Tensor,
                chain_encoding_all: torch.Tensor,
                batch: torch.Tensor)-> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]: 
        if self.augment_eps > 0:
            pos = pos + self.augment_eps * torch.randn_like(pos)
        edge_index, edge_attr, pe_rPa = self._featurize(pos, mask, batch)
        row, col = edge_index[0], edge_index[1]
        offset = residue_idx[col] - residue_idx[row]
        e_chains = ((chain_encoding_all[row] - chain_encoding_all[col]) == 0).long()
        e_pos = self.embedding(offset, e_chains)
        x = self.pe_lin_rPa(self.pe_norm_rPa(pe_rPa))
        edge_attr = self.edge_emb_input_proj(torch.cat([edge_attr, e_pos], dim=-1))        
        valid = mask.to(torch.bool)
        design = valid & chain_mask_all.to(torch.bool)
        unpredicted = design.clone()
        y_masked = chain_seq_label.clone()
        y_masked[unpredicted] = self.mask_token.to(chain_seq_label.dtype)
        return x, y_masked, edge_index, edge_attr, unpredicted, design

class GraphEncoderBlock_fixed_jit(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.channels = 128
        self.local_dropout = 0.1
        self.out_channels = 21
        self.label_emb = torch.nn.Embedding(self.out_channels+1, self.channels)
        self.convs = torch.nn.ModuleList()
        self.edge_updaters = torch.nn.ModuleList()
        self.act = 'silu'
        self.attn_kwargs = {'dropout': 0.0}
        self.num_layers = 10
        self.local_heads=2
        self.global_heads = 4
        
        for _ in range(self.num_layers):
            conv = GPSConv_w_Performer(channels=self.channels, 
                                       conv=TransformerConv(in_channels=self.channels, 
                                                            out_channels=self.channels, 
                                                            heads=self.local_heads,
                                                            concat=False, 
                                                            beta=True, 
                                                            dropout=self.local_dropout, 
                                                            edge_dim=self.channels),
                                        act=self.act,
                                        heads=self.global_heads, 
                                        
                                        attn_kwargs=self.attn_kwargs, 
                                        dropout=self.local_dropout, 
                                        )
            self.convs.append(conv)
            e_up = EdgeUpdateBlock(d_model=self.channels, dropout_rate=self.local_dropout, act=self.act)
            self.edge_updaters.append(e_up)
        self.mlp = torch.nn.Sequential(
                    torch.nn.Linear(self.channels, self.channels *4),
                    activation_resolver(self.act),
                    torch.nn.Dropout(self.local_dropout),
                    torch.nn.Linear(self.channels*4, self.channels),
                    torch.nn.Dropout(self.local_dropout),
                )
        self.classifier = torch.nn.Sequential(
                    torch.nn.Linear(self.channels, self.channels // 2 ),
                    torch.nn.ReLU(),
                    torch.nn.Linear(self.channels// 2, self.channels // 4 ),
                    torch.nn.ReLU(),
                    torch.nn.Linear(self.channels // 4, self.out_channels),
                )
    def forward(self, 
                        x: torch.Tensor,
                        y_to_emb: torch.Tensor, 
                        edge_index: torch.Tensor, 
                        edge_attr: torch.Tensor, 
                        batch: torch.Tensor, 
                        mask: torch.Tensor, 
                        batch_size: int, 
                        max_num_nodes: int):
        x = x + self.label_emb(y_to_emb)
        for conv, e_up in zip(self.convs, self.edge_updaters):
            edge_attr = e_up(h=x, edge_index=edge_index, edge_attr=edge_attr)    
            x = conv(x=x, edge_index=edge_index, batch=batch,
                     valid_mask=mask, edge_attr=edge_attr, batch_size=batch_size, 
                     max_num_nodes=max_num_nodes)
        node_emb = self.mlp(x)               # (N, channels)  <-- embeddings
        logits = self.classifier(node_emb)
        return logits


@torch.inference_mode()
def sample_from_enc(featurizer, model, X, chain_seq_label, mask, chain_mask, 
                    residue_idx, chain_encoding_all, batch,
                    temperature=0.3, deterministic=False,
                    chain_M_pos=None,
                    omit_AAs_np=None, bias_AAs_np=None,
                    omit_AA_mask=None, bias_by_res=None,
                    pssm_coef=None, pssm_bias=None, pssm_multi=None,
                    pssm_log_odds_flag=False, pssm_log_odds_mask=None,
                    pssm_bias_flag=False, isCudaGraph=False):
    device = X.device

    # --- объединяем chain_mask с chain_M_pos и mask, как в оригинале ---
    if chain_M_pos is not None:
        chain_mask_all = chain_mask * chain_M_pos * mask.to(chain_mask.dtype)
    else:
        chain_mask_all = chain_mask * mask.to(chain_mask.dtype)

    x, y_masked, edge_index, edge_attr, unpredicted, design = featurizer(
               pos=X, 
               chain_seq_label=chain_seq_label,
               mask=mask,
               chain_mask_all=chain_mask_all,
               residue_idx=residue_idx,
               chain_encoding_all=chain_encoding_all,
               batch=batch)

    N_total = x.size(0)
    predicted_classes = torch.full((N_total,), -1, dtype=torch.long, device=device)
    B = int(batch.max().item()) + 1
    design_counts = scatter_sum(design.to(torch.float), batch, dim=0, dim_size=B)
    max_iters = int(design_counts.max().item())
    batch_size = B
    ones = torch.ones_like(batch, dtype=x.dtype)
    num_nodes = torch.zeros(batch_size, device=device, dtype=x.dtype)
    max_num_nodes = int(num_nodes.scatter_add(0, batch, ones).max())

    all_probs = torch.zeros((N_total, 21), device=device, dtype=torch.float32)

    # --- omit/bias по аминокислотам, как в оригинале (глобальные, не per-residue) ---
    if omit_AAs_np is not None:
        constant = torch.tensor(omit_AAs_np, device=device, dtype=torch.float32)
    else:
        constant = torch.zeros(21, device=device, dtype=torch.float32)
    if bias_AAs_np is not None:
        constant_bias = torch.tensor(bias_AAs_np, device=device, dtype=torch.float32)
    else:
        constant_bias = torch.zeros(21, device=device, dtype=torch.float32)

    omit_AA_mask_flag = omit_AA_mask is not None

    # --- per-node temperature: делим B графов на len(temperature) равных групп ---
    if isinstance(temperature, (list, tuple)):
        num_temps = len(temperature)
        temp_tensor = torch.tensor([float(t) for t in temperature], device=device)
        graph_ids = torch.arange(B, device=device)
        group_size = (B + num_temps - 1) // num_temps
        temp_idx_per_graph = torch.clamp(graph_ids // group_size, max=num_temps - 1)
        temp_per_graph = temp_tensor[temp_idx_per_graph]
        temp_per_node = temp_per_graph[batch].unsqueeze(-1)  # (N, 1)
    else:
        temp_per_node = torch.full((N_total, 1), float(temperature), device=device)
    # ------------------------------------------------------------------------------
    dec_order = []
    for _ in range(max_iters):
        if isCudaGraph:
            logits = model.run(x, y_masked, edge_index, edge_attr, batch, mask, batch_size, max_num_nodes)
        else:
            logits = model(x=x.clone(),
                        y_to_emb=y_masked,
                        edge_index=edge_index,
                        edge_attr=edge_attr.clone(),
                        batch=batch, 
                        mask=mask, batch_size=batch_size, max_num_nodes=max_num_nodes)
        
        logits = logits / temp_per_node

        if deterministic:
            probs = torch.nn.functional.softmax(
                logits - constant[None, :] * 1e8 + constant_bias[None, :] / temp_per_node,
                dim=-1,
            )
            if bias_by_res is not None:
                probs = torch.nn.functional.softmax(
                    logits - constant[None, :] * 1e8 + constant_bias[None, :] / temp_per_node
                    + bias_by_res / temp_per_node,
                    dim=-1,
                )
        else:
            probs = torch.nn.functional.softmax(
                logits - constant[None, :] * 1e8 + constant_bias[None, :] / temp_per_node
                + (bias_by_res / temp_per_node if bias_by_res is not None else 0.0),
                dim=-1,
            )

        # --- pssm-mixing, как в оригинале ---
        if pssm_bias_flag and pssm_coef is not None and pssm_bias is not None:
            probs = (1 - pssm_multi * pssm_coef[:, None]) * probs + pssm_multi * pssm_coef[:, None] * pssm_bias

        if pssm_log_odds_flag and pssm_log_odds_mask is not None:
            probs_masked = probs * pssm_log_odds_mask
            probs_masked = probs_masked + probs * 0.001
            probs = probs_masked / probs_masked.sum(dim=-1, keepdim=True)

        if omit_AA_mask_flag:
            probs_masked = probs * (1.0 - omit_AA_mask)
            probs = probs_masked / probs_masked.sum(dim=-1, keepdim=True)
        # --------------------------------------

        if deterministic:
            sampled_preds = probs.argmax(-1)
            order = torch.arange(N_total, device=device, dtype=torch.long)
            masked_order = torch.where(unpredicted, order, torch.full_like(order, 10**9))
            first_per_graph, _ = scatter_min(masked_order, batch, dim=0, dim_size=B)
            chosen = (unpredicted & (order == first_per_graph[batch]))
        else:
            sampled_preds = torch.multinomial(probs, num_samples=1).squeeze(-1)
            key = torch.rand(N_total, device=device)
            key = torch.where(unpredicted, key, torch.full_like(key, -1.0))
            key_max_per_graph, _ = scatter_max(key, batch, dim=0, dim_size=B)
            key_max_full = key_max_per_graph[batch]
            chosen = unpredicted & (key >= key_max_full)
        dec_order += [torch.argmax(chosen.to(torch.int)).item()]
        predicted_classes = torch.where(chosen, sampled_preds, predicted_classes)
        all_probs = torch.where(chosen.unsqueeze(-1), probs, all_probs)
        y_masked = torch.where(chosen, sampled_preds, y_masked)
        unpredicted = unpredicted & (~chosen)
        print(torch.argmax(chosen.to(torch.int)).item(), sampled_preds[chosen])
        if torch.argmax(chosen.to(torch.int)).item() == 10:
                        print(logits)
                        import sys
                        sys.exit()
        # print(torch.argmax(chosen.to(torch.int)), predicted_classes, sampled_preds)
        # import sys
        # sys.exit()
    print(dec_order)
    print(y_masked)
    output_dict = {"S": y_masked, "probs": all_probs, "design": design}
    return output_dict