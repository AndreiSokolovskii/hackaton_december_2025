import torch
import numpy as np
from typing import Dict, Optional, Tuple, Union, List
import matplotlib.pyplot as plt
import numpy as np
import py3Dmol
import ipywidgets as widgets
from IPython.display import display
import seaborn as sns

from matplotlib.animation import FuncAnimation
from IPython.display import HTML
def aggregate_residue_scores(attn_global, attn_local, edge_index, N, mode="both"):
    """
    Возвращает per-residue importance score shape (N,)
    mode: 'row'    = исходящее внимание (что данный остаток "смотрит")
          'col'    = входящее внимание (насколько на него смотрят)
          'both'   = симметрично (row+col)/2
          'rollout'= attention rollout через слои
    """
    all_layers = []
    
    for layer_idx in sorted(attn_global.keys()):
        A = attn_global[layer_idx]          # (H, N, N)
        A_avg = A.mean(dim=0)               # (N, N) — среднее по головам
        all_layers.append(A_avg)
    
    if mode == "rollout":
        return attention_rollout(all_layers, N)
    
    # Простая агрегация
    A_stacked = torch.stack(all_layers, dim=0).mean(dim=0)  # (N, N)
    
    row_sum = A_stacked.sum(dim=1)   # сколько внимания i отдаёт
    col_sum = A_stacked.sum(dim=0)   # сколько внимания i получает
    
    if mode == "row":   return row_sum
    if mode == "col":   return col_sum
    if mode == "both":  return (row_sum + col_sum) / 2


def attention_rollout(layer_attns, N, residual_weight=0.5):
    """
    Abnar & Zuidema (2020): рекурсивное перемножение матриц внимания.
    Учитывает skip-connections через residual_weight.
    """
    I = torch.eye(N)
    result = I.clone()
    
    for A in layer_attns:
        # Смешиваем с identity (аналог skip-connection)
        A_res = (1 - residual_weight) * A + residual_weight * I
        A_res = A_res / A_res.sum(dim=-1, keepdim=True)  # ренормализация
        result = A_res @ result
    
    return result.sum(dim=0)  # collapse → (N,)
def aggregate_local_attn(attn_local, edge_index, N):
    """
    attn_local: {layer_idx: Tensor (E,)} — скалярный вес каждого ребра
    Возвращает per-residue score И матрицу контактов (N, N)
    """
    contact_matrix = torch.zeros(N, N)
    
    for layer_idx, edge_weights in attn_local.items():
        src, dst = edge_index  # (E,), (E,)
        # Симметризуем
        for e_idx, (i, j) in enumerate(zip(src, dst)):
            w = edge_weights[e_idx]
            contact_matrix[i, j] += w
            contact_matrix[j, i] += w
    
    contact_matrix /= len(attn_local)  # среднее по слоям
    
    # Per-residue: сумма весов всех рёбер остатка
    residue_scores = contact_matrix.sum(dim=1)
    
    return residue_scores, contact_matrix



def _normalize(arr: np.ndarray, eps: float = 1e-8) -> np.ndarray:
    arr = np.asarray(arr, dtype=float)
    return (arr - arr.min()) / (arr.max() - arr.min() + eps)


def _score_to_hex(score: float, cmap: str = "bwr") -> str:
    r, g, b, _ = plt.get_cmap(cmap)(float(np.clip(score, 0, 1)))
    return "#{:02x}{:02x}{:02x}".format(int(r * 255), int(g * 255), int(b * 255))


def _scores_to_hex_list(scores: np.ndarray, cmap: str = "bwr") -> list[str]:
    return [_score_to_hex(s, cmap) for s in _normalize(scores)]


# ─────────────────────────────────────────────────────────────────────────────
# PDB парсинг
# ─────────────────────────────────────────────────────────────────────────────

def extract_ca_coords(
    pdb_string: str,
) -> Tuple[np.ndarray, list[Tuple[str, int]]]:
    """
    Парсим Cα координаты из PDB-строки.

    Returns
    -------
    ca_coords    : (N, 3)
    residue_info : list[(chain_id, resseq)]
    """
    ca_coords: list[list[float]] = []
    residue_info: list[Tuple[str, int]] = []
    seen: set = set()

    for line in pdb_string.splitlines():
        if not line.startswith(("ATOM", "HETATM")):
            continue
        if line[12:16].strip() != "CA":
            continue
        chain = line[21]
        try:
            resseq = int(line[22:26].strip())
        except ValueError:
            continue
        key = (chain, resseq)
        if key in seen:
            continue
        seen.add(key)
        try:
            x, y, z = float(line[30:38]), float(line[38:46]), float(line[46:54])
        except ValueError:
            continue
        ca_coords.append([x, y, z])
        residue_info.append(key)

    return np.array(ca_coords, dtype=float), residue_info


# ─────────────────────────────────────────────────────────────────────────────
# Агрегация: GLOBAL attention
# ─────────────────────────────────────────────────────────────────────────────

def get_global_attn_matrix(
    attn_global: Dict[int, torch.Tensor],
    layer: int,
    head: Union[int, str],          # int | "average"
) -> np.ndarray:
    """(H, N, N) → (N, N)"""
    A = attn_global[layer].float()  # (H, N, N)
    if head == "average":
        return A.mean(dim=0).detach().cpu().numpy()
    return A[int(head)].detach().cpu().numpy()


def compute_residue_scores_from_global(
    A: np.ndarray,
    mode: str = "both",
) -> np.ndarray:
    """
    (N, N) → (N,)

    mode
    ----
    'row'    : исходящее внимание (query)
    'col'    : входящее  внимание (key)
    'both'   : (row + col) / 2
    'max_row': max по строке
    """
    row = A.sum(axis=1)
    col = A.sum(axis=0)
    if mode == "row":     return row
    if mode == "col":     return col
    if mode == "both":    return (row + col) / 2
    if mode == "max_row": return A.max(axis=1)
    raise ValueError(f"Unknown mode: {mode!r}")


def attention_rollout(
    attn_global: Dict[int, torch.Tensor],
    head: Union[int, str] = "average",
    residual_weight: float = 0.5,
) -> np.ndarray:
    """
    Abnar & Zuidema (2020): перемножение матриц внимания через все слои.
    Возвращает (N,) per-residue score.
    """
    layers = sorted(attn_global.keys())
    N = attn_global[layers[0]].shape[-1]
    result = np.eye(N)
    for layer in layers:
        A = get_global_attn_matrix(attn_global, layer, head)
        A_res = (1 - residual_weight) * A + residual_weight * np.eye(N)
        A_res /= A_res.sum(axis=1, keepdims=True) + 1e-8
        result = A_res @ result
    return result.sum(axis=0)


# ─────────────────────────────────────────────────────────────────────────────
# Агрегация: LOCAL attention  (multi-head sparse)
# ─────────────────────────────────────────────────────────────────────────────

def get_local_edge_weights(
    attn_local: Dict[int, Tuple[torch.Tensor, torch.Tensor]],
    layer: int,
    local_head: Union[int, str] = "average",   # int | "average" | "max"
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Распаковывает локальное внимание для заданного слоя и головы.

    Parameters
    ----------
    attn_local  : {layer: (edge_index (2,E), weights (E, H_local))}
    local_head  : номер головы, "average" или "max"

    Returns
    -------
    edge_index  : (2, E)  np.ndarray
    edge_weights: (E,)    np.ndarray — уже агрегированные по головам
    """
    ei, ew = attn_local[layer]

    ei_np = ei.detach().cpu().numpy() if isinstance(ei, torch.Tensor) else np.asarray(ei)
    # ew: (E, H_local)
    ew_np = ew.float().detach().cpu().numpy() if isinstance(ew, torch.Tensor) else np.asarray(ew, dtype=float)

    if ew_np.ndim == 1:
        # На случай если вдруг передали уже агрегированный (E,)
        return ei_np, ew_np

    # ew_np.shape == (E, H_local)
    if local_head == "average":
        weights_1d = ew_np.mean(axis=1)   # (E,)
    elif local_head == "max":
        weights_1d = ew_np.max(axis=1)    # (E,)
    else:
        weights_1d = ew_np[:, int(local_head)]   # (E,)

    return ei_np, weights_1d


def compute_residue_scores_from_local(
    attn_local: Dict[int, Tuple[torch.Tensor, torch.Tensor]],
    layer: int,
    local_head: Union[int, str],
    N: int,
    mode: str = "both",
) -> np.ndarray:
    """
    Агрегирует (E, H_local) → (N,) per-residue score.

    mode
    ----
    'both' : sum(incoming) + sum(outgoing) на каждый узел
    'row'  : только исходящее (src)
    'col'  : только входящее  (dst)
    """
    ei_np, ew_1d = get_local_edge_weights(attn_local, layer, local_head)
    src, dst = ei_np[0], ei_np[1]

    out_scores = np.zeros(N)
    in_scores  = np.zeros(N)
    np.add.at(out_scores, src, ew_1d)
    np.add.at(in_scores,  dst, ew_1d)

    if mode == "row":  return out_scores
    if mode == "col":  return in_scores
    return (out_scores + in_scores) / 2   # "both"


def get_local_head_count(
    attn_local: Dict[int, Tuple[torch.Tensor, torch.Tensor]],
) -> int:
    """Сколько голов у локального внимания."""
    layer0 = next(iter(attn_local.values()))
    _, ew = layer0
    ew_np = ew.detach().cpu().numpy() if isinstance(ew, torch.Tensor) else np.asarray(ew)
    return 1 if ew_np.ndim == 1 else ew_np.shape[1]


def make_local_attn_matrix(
    attn_local: Dict[int, Tuple[torch.Tensor, torch.Tensor]],
    layer: int,
    local_head: Union[int, str],
    N: int,
) -> np.ndarray:
    """
    Строит плотную (N, N) матрицу из sparse локального внимания —
    удобно для визуализации heatmap рядом с глобальным.
    Нулевые элементы соответствуют отсутствующим рёбрам.
    """
    ei_np, ew_1d = get_local_edge_weights(attn_local, layer, local_head)
    M = np.zeros((N, N))
    src, dst = ei_np[0], ei_np[1]
    valid = (src < N) & (dst < N)
    M[src[valid], dst[valid]] = ew_1d[valid]
    return M


# ─────────────────────────────────────────────────────────────────────────────
# 3D визуализация (py3Dmol)
# ─────────────────────────────────────────────────────────────────────────────

def make_3d_view(
    pdb_string: str,
    residue_scores: np.ndarray,
    residue_info: list[Tuple[str, int]],
    ca_coords: np.ndarray,
    edge_index: Optional[np.ndarray] = None,       # (2, E)
    edge_weights: Optional[np.ndarray] = None,     # (E,)  уже агрегированные
    top_k_edges: int = 40,
    show_edges: bool = True,
    cmap: str = "bwr",
    width: int = 700,
    height: int = 480,
) -> py3Dmol.view:
    hex_colors = _scores_to_hex_list(residue_scores, cmap)

    view = py3Dmol.view(width=width, height=height)
    view.addModel(pdb_string, "pdb")
    view.setStyle({"cartoon": {"color": "#cccccc"}})

    for (chain, resseq), color in zip(residue_info, hex_colors):
        view.setStyle(
            {"chain": chain, "resi": resseq},
            {"cartoon": {"color": color}},
        )

    if show_edges and edge_index is not None and edge_weights is not None:
        ew = _normalize(edge_weights.flatten())
        k  = min(top_k_edges, len(ew))
        top_idx = np.argsort(ew)[-k:]

        for idx in top_idx:
            i, j = int(edge_index[0, idx]), int(edge_index[1, idx])
            if i >= len(ca_coords) or j >= len(ca_coords):
                continue
            w = float(ew[idx])
            x1, y1, z1 = ca_coords[i].tolist()
            x2, y2, z2 = ca_coords[j].tolist()

            view.addCylinder({
                "start":   {"x": x1, "y": y1, "z": z1},
                "end":     {"x": x2, "y": y2, "z": z2},
                "radius":  0.04 + w * 0.20,
                "color":   _score_to_hex(w, cmap),
                "opacity": 0.25 + 0.75 * w,
            })

    view.zoomTo()
    return view


# ─────────────────────────────────────────────────────────────────────────────
# 2D визуализация (matplotlib)
# ─────────────────────────────────────────────────────────────────────────────

def plot_attention_panel(
    A_global: np.ndarray,
    A_local:  np.ndarray,
    residue_scores: np.ndarray,
    layer: int,
    global_head: Union[int, str],
    local_head:  Union[int, str],
    mode: str,
    residue_info: Optional[list] = None,
    figsize: Tuple[int, int] = (16, 4),
    cmap: str = "bwr",
):
    N = A_global.shape[0]
    fig, axes = plt.subplots(1, 3, figsize=figsize)

    def _heatmap(ax, M, title, cmap):
        im = ax.imshow(M, cmap=cmap, aspect="auto", vmin=0, vmax=M.max())
        plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        ax.set_title(title, fontsize=9)
        ax.set_xlabel("j (key / dst)")
        ax.set_ylabel("i (query / src)")
        if N <= 60 and residue_info is not None:
            labels = [f"{ch}{r}" for ch, r in residue_info]
            ax.set_xticks(range(N)); ax.set_xticklabels(labels, rotation=90, fontsize=5)
            ax.set_yticks(range(N)); ax.set_yticklabels(labels, fontsize=5)

    _heatmap(axes[0], A_global,
             f"Global attn  |  layer {layer}, head {global_head}", cmap=cmap)
    _heatmap(axes[1], A_local,
             f"Local attn (dense view)  |  layer {layer}, head {local_head}", cmap=cmap)

    normed = _normalize(residue_scores)
    colors = [plt.get_cmap(cmap)(s) for s in normed]
    axes[2].bar(range(N), normed, color=colors, width=1.0)
    axes[2].set_title(f"Per-residue score  |  mode: {mode}", fontsize=9)
    axes[2].set_xlabel("Residue index")
    axes[2].set_ylabel("Normalised")
    axes[2].set_xlim(-0.5, N - 0.5)

    plt.tight_layout()
    plt.show()


# ─────────────────────────────────────────────────────────────────────────────
# Интерактивный виджет
# ─────────────────────────────────────────────────────────────────────────────

def interactive_attention_viewer(
    pdb_string:  str,
    attn_global: Dict[int, torch.Tensor],                       # {layer: (H_g, N, N)}
    attn_local:  Dict[int, Tuple[torch.Tensor, torch.Tensor]],  # {layer: ((2,E), (E,H_l))}
    chain_id:    str = "A",
    cmap:        str = "jet",
    width:       int = 700,
    height:      int = 460,
):
    ca_coords, residue_info = extract_ca_coords(pdb_string)
    N = attn_global[next(iter(attn_global))].shape[-1]
    n_layers       = len(attn_global)
    n_global_heads = attn_global[next(iter(attn_global))].shape[0]
    n_local_heads  = get_local_head_count(attn_local)

    # ── Виджеты ─────────────────────────────────────────────────────────────
    def _slider(label, lo, hi, val=0):
        return widgets.IntSlider(
            value=val, min=lo, max=hi, step=1,
            description=label, continuous_update=False,
            layout=widgets.Layout(width="340px"),
        )
    def _dd(label, options, val=None):
        return widgets.Dropdown(
            options=options, value=val or options[0],
            description=label, layout=widgets.Layout(width="210px"),
        )

    layer_sl       = _slider("Layer:",        0, n_layers - 1)
    global_head_dd = _dd("Global head:",
                         ["average"] + list(range(n_global_heads)))
    local_head_dd  = _dd("Local head:",
                         ["average", "max"] + list(range(n_local_heads)))
    mode_dd        = _dd("Score mode:",  ["both", "row", "col", "max_row", "rollout"])
    source_dd      = _dd("Source:",      ["global", "local", "both"])
    topk_sl        = _slider("Top-K edges:", 5, 200, 40)
    show_edges_cb  = widgets.Checkbox(
        value=True, description="Show edges", indent=False)
    update_btn     = widgets.Button(
        description="▶ Update", button_style="primary",
        layout=widgets.Layout(width="120px"),
    )

    out_3d   = widgets.Output()
    out_plot = widgets.Output()

    # ── Render ───────────────────────────────────────────────────────────────
    def render(_b=None):
        layer       = layer_sl.value
        g_head      = global_head_dd.value
        l_head      = local_head_dd.value
        mode        = mode_dd.value
        source      = source_dd.value
        top_k       = topk_sl.value
        show_e      = show_edges_cb.value

        # ── Global attention ─────────────────────────────────────────────────
        if mode == "rollout":
            g_scores  = attention_rollout(attn_global, head=g_head)
            A_global  = get_global_attn_matrix(attn_global, layer, g_head)
        else:
            A_global  = get_global_attn_matrix(attn_global, layer, g_head)
            g_scores  = compute_residue_scores_from_global(A_global, mode)

        # ── Local attention ──────────────────────────────────────────────────
        ei_np, ew_1d = get_local_edge_weights(attn_local, layer, l_head)
        A_local      = make_local_attn_matrix(attn_local, layer, l_head, N)
        l_scores     = compute_residue_scores_from_local(
                           attn_local, layer, l_head, N,
                           mode=mode if mode != "rollout" else "both")

        # ── Итоговые скоры для раскраски ─────────────────────────────────────
        if source == "global":
            final_scores = g_scores
            plot_ei, plot_ew = None, None
        elif source == "local":
            final_scores = l_scores
            plot_ei, plot_ew = ei_np, ew_1d
        else:   # both
            final_scores = (_normalize(g_scores) + _normalize(l_scores)) / 2
            plot_ei, plot_ew = ei_np, ew_1d

        # ── Обрезаем до длины residue_info ───────────────────────────────────
        n_res = min(N, len(residue_info))
        fs    = final_scores[:n_res]
        ri    = residue_info[:n_res]
        ca    = ca_coords[:n_res]

        # ── 3D ───────────────────────────────────────────────────────────────
        out_3d.clear_output(wait=True)
        with out_3d:
            view = make_3d_view(
                pdb_string     = pdb_string,
                residue_scores = fs,
                residue_info   = ri,
                ca_coords      = ca,
                edge_index     = plot_ei if show_e else None,
                edge_weights   = plot_ew if show_e else None,
                top_k_edges    = top_k,
                show_edges     = show_e,
                cmap           = cmap,
                width          = width,
                height         = height,
            )
            view.show()

        # ── 2D ───────────────────────────────────────────────────────────────
        out_plot.clear_output(wait=True)
        with out_plot:
            plot_attention_panel(
                A_global       = A_global[:n_res, :n_res],
                A_local        = A_local[:n_res, :n_res],
                residue_scores = fs,
                layer          = layer,
                global_head    = g_head,
                local_head     = l_head,
                mode           = mode,
                residue_info   = ri,
                cmap           = cmap,
            )

    update_btn.on_click(render)

    controls = widgets.VBox([
        widgets.HBox([layer_sl,      global_head_dd, local_head_dd]),
        widgets.HBox([mode_dd,       source_dd]),
        widgets.HBox([topk_sl,       show_edges_cb]),
        update_btn,
    ])
    display(widgets.VBox([controls, widgets.HBox([out_3d, out_plot])]))
    render()


# ─────────────────────────────────────────────────────────────────────────────
# Быстрый одиночный рендер (без виджетов)
# ─────────────────────────────────────────────────────────────────────────────

def quick_view(
    pdb_string:  str,
    attn_global: Dict[int, torch.Tensor],
    attn_local:  Dict[int, Tuple[torch.Tensor, torch.Tensor]],
    layer:       int = 0,
    global_head: Union[int, str] = "average",
    local_head:  Union[int, str] = "average",
    mode:        str = "both",
    source:      str = "global",
    top_k:       int = 40,
    cmap:        str = "bwr",
):
    ca_coords, residue_info = extract_ca_coords(pdb_string)
    N = attn_global[next(iter(attn_global))].shape[-1]

    A_global = get_global_attn_matrix(attn_global, layer, global_head)
    g_scores = (attention_rollout(attn_global, head=global_head)
                if mode == "rollout"
                else compute_residue_scores_from_global(A_global, mode))

    ei_np, ew_1d = get_local_edge_weights(attn_local, layer, local_head)
    A_local      = make_local_attn_matrix(attn_local, layer, local_head, N)
    l_scores     = compute_residue_scores_from_local(
                       attn_local, layer, local_head, N,
                       mode=mode if mode != "rollout" else "both")

    if source == "global":
        final_scores, plot_ei, plot_ew = g_scores, None, None
    elif source == "local":
        final_scores, plot_ei, plot_ew = l_scores, ei_np, ew_1d
    else:
        final_scores = (_normalize(g_scores) + _normalize(l_scores)) / 2
        plot_ei, plot_ew = ei_np, ew_1d

    n_res = min(N, len(residue_info))
    view = make_3d_view(
        pdb_string=pdb_string,
        residue_scores=final_scores[:n_res],
        residue_info=residue_info[:n_res],
        ca_coords=ca_coords[:n_res],
        edge_index=plot_ei,
        edge_weights=plot_ew,
        top_k_edges=top_k,
        cmap=cmap,
    )
    view.show()

    plot_attention_panel(
        A_global=A_global[:n_res, :n_res],
        A_local=A_local[:n_res, :n_res],
        residue_scores=final_scores[:n_res],
        layer=layer,
        global_head=global_head,
        local_head=local_head,
        mode=mode,
        residue_info=residue_info[:n_res],
    )




def compute_step_scores(
    attn_global_steps: List[Dict[int, torch.Tensor]],
    layer: int,
    head: Union[int, str] = "average",
    mode: str = "both",
    N_final: Optional[int] = None,
) -> np.ndarray:
    """
    Возвращает (T, N_final) — per-residue score на каждом шаге сэмплинга,
    с паддингом нулями для остатков, которых ещё нет на данном шаге.

    Полезно считать mode='rollout' отдельно — тяжелее (перемножение по слоям
    на каждом шаге), но честно отражает то, что "видит" модель на шаге t.
    """
    N_final = N_final or attn_global_steps[-1][layer].shape[-1]
    scores = np.zeros((len(attn_global_steps), N_final))

    for t, attn_t in enumerate(attn_global_steps):
        N_t = attn_t[layer].shape[-1]
        if mode == "rollout":
            s_t = attention_rollout(attn_t, head=head)
        else:
            A_t = get_global_attn_matrix(attn_t, layer, head)
            s_t = compute_residue_scores_from_global(A_t, mode)
        scores[t, :N_t] = s_t

    return scores


def _decoded_mask(attn_global_steps, layer) -> np.ndarray:
    """(T, N_final) bool — какие остатки уже "раскрыты" на шаге t."""
    N_final = attn_global_steps[-1][layer].shape[-1]
    mask = np.zeros((len(attn_global_steps), N_final), dtype=bool)
    for t, attn_t in enumerate(attn_global_steps):
        N_t = attn_t[layer].shape[-1]
        mask[t, :N_t] = True
    return mask


# ─────────────────────────────────────────────────────────────────────────────
# 1. Нативная py3Dmol-анимация через B-factor trajectory (только cartoon)
# ─────────────────────────────────────────────────────────────────────────────

def build_multiframe_pdb(
    pdb_string: str,
    scores_per_step: np.ndarray,      # (T, N)
    residue_info: List[Tuple[str, int]],
    decoded_mask: Optional[np.ndarray] = None,  # (T, N) bool
) -> str:
    """
    Клонирует исходный PDB T раз как отдельные MODEL-блоки, подставляя
    в колонку B-factor нормализованный score текущего шага (per-residue,
    один и тот же для всех атомов остатка). Не раскрытые остатки (mask=False)
    получают b=-1 как сентинел — в раскраске это можно смэпить на серый.
    """
    T, N = scores_per_step.shape
    res_key_to_idx = {key: i for i, key in enumerate(residue_info)}
    normed = _normalize(scores_per_step)  # нормализация по всему трэку сразу,
                                           # чтобы цвет был сопоставим между шагами

    lines_by_atom = []
    for line in pdb_string.splitlines():
        if line.startswith(("ATOM", "HETATM")):
            chain = line[21]
            try:
                resseq = int(line[22:26].strip())
            except ValueError:
                lines_by_atom.append((line, None))
                continue
            lines_by_atom.append((line, res_key_to_idx.get((chain, resseq))))
        else:
            lines_by_atom.append((line, "SKIP"))

    frames = []
    for t in range(T):
        buf = [f"MODEL     {t + 1:>4}"]
        for line, res_idx in lines_by_atom:
            if res_idx == "SKIP":
                continue  # заголовки/HEADER и т.п. не дублируем в каждый MODEL
            if res_idx is None:
                buf.append(line)
                continue
            if decoded_mask is not None and not decoded_mask[t, res_idx]:
                b = -1.0
            else:
                b = float(normed[t, res_idx])
            # PDB b-factor: колонки 61-66, формат %6.2f
            new_line = line[:60] + f"{b:6.2f}" + line[66:]
            buf.append(new_line)
        buf.append("ENDMDL")
        frames.append("\n".join(buf))

    return "\n".join(frames) + "\nEND\n"


def animate_sampling_attention(
    pdb_string: str,
    attn_global_steps: List[Dict[int, torch.Tensor]],
    layer: int,
    head: Union[int, str] = "average",
    mode: str = "both",
    interval_ms: int = 250,
    cmap_min: float = 0.0,
    cmap_max: float = 1.0,
    width: int = 700,
    height: int = 480,
) -> py3Dmol.view:
    """
    Возвращает py3Dmol.view с уже настроенным play/pause по шагам сэмплинга.
    Раскраска идёт по B-factor через встроенный gradient (без ручного
    пересчёта hex на каждый кадр — это и даёт плавность).
    """
    ca_coords, residue_info = extract_ca_coords(pdb_string)
    scores = compute_step_scores(attn_global_steps, layer, head, mode)
    mask = _decoded_mask(attn_global_steps, layer)

    multim_pdb = build_multiframe_pdb(pdb_string, scores, residue_info, mask)

    view = py3Dmol.view(width=width, height=height)
    view.addModelsAsFrames(multim_pdb, "pdb")
    # b=-1 (не раскрыт) -> серый, иначе градиент rwb в [cmap_min, cmap_max]
    view.setStyle({}, {"cartoon": {
        "colorscheme": {
            "prop": "b",
            "gradient": "rwb",
            "min": cmap_min,
            "max": cmap_max,
        }
    }})
    view.setStyle({"b": -1}, {"cartoon": {"color": "#888888"}})
    view.zoomTo()
    view.animate({"loop": "forward", "interval": interval_ms})
    return view


# ─────────────────────────────────────────────────────────────────────────────
# 2. Покадровый рендер в GIF/MP4 (поддерживает рёбра local attention)
# ─────────────────────────────────────────────────────────────────────────────

def render_sampling_to_gif(
    pdb_string: str,
    attn_global_steps: List[Dict[int, torch.Tensor]],
    attn_local_steps: List[Dict[int, Tuple[torch.Tensor, torch.Tensor]]],
    layer: int,
    out_path: str = "sampling_attention.gif",
    global_head: Union[int, str] = "average",
    local_head: Union[int, str] = "average",
    mode: str = "both",
    source: str = "both",
    top_k_edges: int = 40,
    cmap: str = "bwr",
    fps: int = 4,
    width: int = 700,
    height: int = 480,
):
    """
    Требует `pip install imageio`. Рендерит каждый шаг через make_3d_view
    (то есть с рёбрами), делает screenshot и склеивает в GIF.

    ВАЖНО: view.png() в py3Dmol асинхронный в браузере/JS-рантайме ноутбука —
    в headless-режиме (без display) может понадобиться `imageio` + selenium/
    headless chrome backend, либо экспорт через `nglview`/`py3Dmol`'s
    `view.write_html` + внешний скриншотер. Если рендер в вашем окружении
    не headless (обычный Jupyter), проще п.3 (interactive_step_scrubber)
    и ручной экспорт кадров через "Save image" в самом виджете.
    """
    import imageio.v2 as imageio

    ca_coords, residue_info = extract_ca_coords(pdb_string)
    N_final = attn_global_steps[-1][layer].shape[-1]
    frames_png = []

    for t, (attn_g, attn_l) in enumerate(zip(attn_global_steps, attn_local_steps)):
        N_t = attn_g[layer].shape[-1]

        A_g = get_global_attn_matrix(attn_g, layer, global_head)
        g_scores = (attention_rollout(attn_g, head=global_head)
                    if mode == "rollout"
                    else compute_residue_scores_from_global(A_g, mode))

        ei_np, ew_1d = get_local_edge_weights(attn_l, layer, local_head)
        l_scores = compute_residue_scores_from_local(
            attn_l, layer, local_head, N_t,
            mode=mode if mode != "rollout" else "both")

        if source == "global":
            final_scores, plot_ei, plot_ew = g_scores, None, None
        elif source == "local":
            final_scores, plot_ei, plot_ew = l_scores, ei_np, ew_1d
        else:
            final_scores = (_normalize(g_scores) + _normalize(l_scores)) / 2
            plot_ei, plot_ew = ei_np, ew_1d

        view = make_3d_view(
            pdb_string=pdb_string,
            residue_scores=final_scores,
            residue_info=residue_info[:N_t],
            ca_coords=ca_coords[:N_t],
            edge_index=plot_ei,
            edge_weights=plot_ew,
            top_k_edges=top_k_edges,
            cmap=cmap,
            width=width,
            height=height,
        )
        png_bytes = view.png()  # base64 PNG в py3Dmol >= 2.x
        frames_png.append(imageio.imread(png_bytes))

    imageio.mimsave(out_path, frames_png, fps=fps)
    return out_path


# ─────────────────────────────────────────────────────────────────────────────
# 3. Интерактивный scrubber по шагам (полный пересчёт сцены на каждый шаг)
# ─────────────────────────────────────────────────────────────────────────────

import json
import re
from IPython.display import Javascript


def _extract_viewer_uid(view: py3Dmol.view) -> str:
    """
    py3Dmol не публикует стабильный API для получения id JS-переменной
    вьюера, но `.uniqueid` есть в большинстве версий пакета. Как fallback
    вытаскиваем его regex'ом из сгенерированного HTML (там JS-переменная
    называется `viewer_<uniqueid>`) — на случай, если атрибут переименуют
    в будущей версии py3Dmol.
    """
    uid = getattr(view, "uniqueid", None)
    if uid:
        return uid
    html = view._make_html() if hasattr(view, "_make_html") else view._repr_html_()
    m = re.search(r"viewer_([0-9a-fA-F]{16,32})", html)
    if not m:
        raise RuntimeError(
            "Не удалось определить id JS-переменной py3Dmol-вьюера — "
            "вероятно, изменился внутренний формат генерируемого HTML. "
            "Посмотрите глазами вывод view._repr_html_() и найдите "
            "переменную вида `viewer_XXXX`, чтобы поправить regex."
        )
    return m.group(1)


def _build_update_js(
    viewer_uid: str,
    pdb_string: str,
    residue_scores: np.ndarray,
    residue_info: List[Tuple[str, int]],
    ca_coords: np.ndarray,
    edge_index: Optional[np.ndarray],
    edge_weights: Optional[np.ndarray],
    top_k_edges: int,
    cmap: str,
    do_zoom: bool,
) -> str:
    """
    Строит JS, который обновляет УЖЕ СУЩЕСТВУЮЩИЙ вьюер `viewer_<uid>`
    in-place (без пересоздания canvas), поэтому камера не сбрасывается
    сама по себе. zoomTo() вызывается только если явно попросили (do_zoom).
    """
    hex_colors = _scores_to_hex_list(residue_scores, cmap)

    lines = [f"var v = viewer_{viewer_uid};",
             "v.removeAllModels(); v.removeAllShapes();",
             f"v.addModel({json.dumps(pdb_string)}, 'pdb');",
             "v.setStyle({}, {cartoon: {color: '#cccccc'}});"]

    for (chain, resseq), color in zip(residue_info, hex_colors):
        lines.append(
            f"v.setStyle({{chain:{json.dumps(chain)}, resi:{resseq}}}, "
            f"{{cartoon: {{color:{json.dumps(color)}}}}});"
        )

    if edge_index is not None and edge_weights is not None and len(edge_weights) > 0:
        ew = _normalize(np.asarray(edge_weights).flatten())
        k = min(top_k_edges, len(ew))
        top_idx = np.argsort(ew)[-k:]
        for idx in top_idx:
            i, j = int(edge_index[0, idx]), int(edge_index[1, idx])
            if i >= len(ca_coords) or j >= len(ca_coords):
                continue
            w = float(ew[idx])
            x1, y1, z1 = ca_coords[i].tolist()
            x2, y2, z2 = ca_coords[j].tolist()
            color = _score_to_hex(w, cmap)
            lines.append(
                "v.addCylinder({"
                f"start:{{x:{x1},y:{y1},z:{z1}}}, end:{{x:{x2},y:{y2},z:{z2}}}, "
                f"radius:{0.04 + w * 0.20}, color:{json.dumps(color)}, "
                f"opacity:{0.25 + 0.75 * w}}});"
            )

    if do_zoom:
        lines.append("v.zoomTo();")
    lines.append("v.render();")
    return "\n".join(lines)

def _capture_camera(view: py3Dmol.view):
    """
    Пытается вытащить текущую камеру виджета через py3Dmol.getView().
    Работает в classic Jupyter (синхронный round-trip через comm);
    в некоторых окружениях (JupyterLab/VSCode с новым фронтендом,
    headless) может не поддерживаться — тогда просто возвращаем None
    и камера на новом кадре не блокируется/не восстанавливается.
    """
    try:
        return view.getView()
    except Exception:
        return None


def _apply_camera(view: py3Dmol.view, camera_state) -> None:
    if camera_state is not None:
        try:
            view.setView(camera_state)
        except Exception:
            pass
def interactive_step_scrubber(
    pdb_string: str,
    attn_global_steps: List[Dict[int, torch.Tensor]],
    attn_local_steps: List[Dict[int, Tuple[torch.Tensor, torch.Tensor]]],
    layer: int = 0,
    cmap: str = "jet",
    width: int = 700,
    height: int = 460,
):
    """
    Play/pause + слайдер по шагам сэмплинга и слайдер по слою, с полным
    пересчётом 3D-сцены (включая рёбра) на каждом шаге. Медленнее анимации
    через B-factor, но не требует imageio/headless-рендера и остаётся
    интерактивным.

    Добавлено по сравнению с первой версией:
      - слайдер Layer (не только фиксированный layer из аргумента)
      - Local head можно выбрать конкретный номер, не только average/max
      - "Lock camera" — сохраняет ориентацию камеры между кадрами при
        проигрывании/скраббинге
      - кнопка "Export" — рендерит текущие настройки по всем шагам в GIF
    """
    ca_coords, residue_info = extract_ca_coords(pdb_string)
    T = len(attn_global_steps)
    n_layers = len(attn_global_steps[0])
    n_local_heads = get_local_head_count(attn_local_steps[0])

    layer_sl = widgets.IntSlider(
        value=layer, min=0, max=n_layers - 1, description="Layer:")
    global_head_dd = widgets.Dropdown(
        options=["average"] + list(range(attn_global_steps[0][layer].shape[0])),
        value="average", description="Global head:")
    local_head_dd = widgets.Dropdown(
        options=["average", "max"] + list(range(n_local_heads)),
        value="average", description="Local head:")
    mode_dd = widgets.Dropdown(
        options=["both", "row", "col", "rollout"], value="both", description="Mode:")
    source_dd = widgets.Dropdown(
        options=["global", "local", "both"], value="both", description="Source:")
    topk_sl = widgets.IntSlider(value=40, min=5, max=200, description="Top-K edges:")
    lock_camera_cb = widgets.Checkbox(
        value=True, description="Lock camera between frames", indent=False)

    step_sl = widgets.IntSlider(value=0, min=0, max=T - 1, description="Step:")
    play = widgets.Play(value=0, min=0, max=T - 1, interval=300)
    widgets.jslink((play, "value"), (step_sl, "value"))

    export_btn = widgets.Button(
        description="⬇ Export animation", button_style="info",
        layout=widgets.Layout(width="160px"))
    export_status = widgets.Label(value="")

    out_3d = widgets.Output()
    camera_state = {"v": None}  # хранит последнюю пойманную камеру между рендерами

    def _compute_scores_and_edges(t, lyr):
        attn_g, attn_l = attn_global_steps[t], attn_local_steps[t]
        N_t = attn_g[lyr].shape[-1]

        A_g = get_global_attn_matrix(attn_g, lyr, global_head_dd.value)
        g_scores = (attention_rollout(attn_g, head=global_head_dd.value)
                    if mode_dd.value == "rollout"
                    else compute_residue_scores_from_global(A_g, mode_dd.value))

        ei_np, ew_1d = get_local_edge_weights(attn_l, lyr, local_head_dd.value)
        l_scores = compute_residue_scores_from_local(
            attn_l, lyr, local_head_dd.value, N_t,
            mode=mode_dd.value if mode_dd.value != "rollout" else "both")

        if source_dd.value == "global":
            final_scores, plot_ei, plot_ew = g_scores, None, None
        elif source_dd.value == "local":
            final_scores, plot_ei, plot_ew = l_scores, ei_np, ew_1d
        else:
            final_scores = (_normalize(g_scores) + _normalize(l_scores)) / 2
            plot_ei, plot_ew = ei_np, ew_1d

        return N_t, final_scores, plot_ei, plot_ew

    def render(_=None):
        t, lyr = step_sl.value, layer_sl.value
        N_t, final_scores, plot_ei, plot_ew = _compute_scores_and_edges(t, lyr)

        out_3d.clear_output(wait=True)
        with out_3d:
            view = make_3d_view(
                pdb_string=pdb_string,
                residue_scores=final_scores,
                residue_info=residue_info[:N_t],
                ca_coords=ca_coords[:N_t],
                edge_index=plot_ei,
                edge_weights=plot_ew,
                top_k_edges=topk_sl.value,
                cmap=cmap,
                width=width,
                height=height,
            )
            if lock_camera_cb.value:
                if camera_state["v"] is None:
                    # первый кадр — ловим стартовую камеру после zoomTo()
                    camera_state["v"] = _capture_camera(view)
                else:
                    _apply_camera(view, camera_state["v"])
            view.show()
            if lock_camera_cb.value:
                # обновляем сохранённую камеру уже после показа — если юзер
                # покрутил структуру руками на предыдущем кадре, следующий
                # рендер подхватит именно этот ракурс, а не исходный zoomTo()
                new_state = _capture_camera(view)
                if new_state is not None:
                    camera_state["v"] = new_state

    def on_lock_toggle(change):
        if not change["new"]:
            camera_state["v"] = None  # сброс: следующий рендер снова zoomTo()

    lock_camera_cb.observe(on_lock_toggle, names="value")

    def export_animation(_btn=None):
        export_status.value = "Rendering frames…"
        try:
            import imageio.v2 as imageio
        except ImportError:
            export_status.value = "⚠ нужен `pip install imageio`"
            return

        frames_png = []
        lyr = layer_sl.value
        export_view_state = camera_state["v"]  # используем текущий залоченный ракурс

        try:
            for t in range(T):
                N_t, final_scores, plot_ei, plot_ew = _compute_scores_and_edges(t, lyr)
                view = make_3d_view(
                    pdb_string=pdb_string,
                    residue_scores=final_scores,
                    residue_info=residue_info[:N_t],
                    ca_coords=ca_coords[:N_t],
                    edge_index=plot_ei,
                    edge_weights=plot_ew,
                    top_k_edges=topk_sl.value,
                    cmap=cmap,
                    width=width,
                    height=height,
                )
                _apply_camera(view, export_view_state)
                png_bytes = view.png()
                frames_png.append(imageio.imread(png_bytes))
                export_status.value = f"Rendering frames… {t + 1}/{T}"
        except Exception as e:
            # png()-рендер в headless/некоторых Lab-окружениях может не работать —
            # см. предупреждение в render_sampling_to_gif()
            export_status.value = f"⚠ рендер сорвался на кадре {len(frames_png)}: {e}"
            return

        out_path = f"sampling_attn_layer{lyr}.gif"
        imageio.mimsave(out_path, frames_png, fps=4)
        export_status.value = f"✅ сохранено: {out_path}"

    export_btn.on_click(export_animation)

    step_sl.observe(render, names="value")
    layer_sl.observe(render, names="value")
    for w in (global_head_dd, local_head_dd, mode_dd, source_dd, topk_sl):
        w.observe(render, names="value")

    controls = widgets.VBox([
        widgets.HBox([play, step_sl]),
        widgets.HBox([layer_sl]),
        widgets.HBox([global_head_dd, local_head_dd, mode_dd, source_dd, topk_sl]),
        widgets.HBox([lock_camera_cb, export_btn, export_status]),
    ])
    display(widgets.VBox([controls, out_3d]))
    render()
def get_animation(attn_list,  cmap='bwr_r'):
    fig, ax = plt.subplots(figsize=(6, 5))
    def update(frame):
        ax.clear()
        sns.heatmap(attn_list[frame], ax=ax, cmap=cmap, square=True, cbar=False, center=0, cbar_kws={"shrink": 0.5})
        ax.set_title(f"Frame: {frame}")
    anim = FuncAnimation(fig, update, frames=len(attn_list), interval=500)
    plt.close()
    return anim