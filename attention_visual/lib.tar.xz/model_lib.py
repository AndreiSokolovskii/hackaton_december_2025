import torch
import math
from itertools import product
from torch_geometric.nn.conv import MessagePassing
from torch_geometric.nn import TransformerConv, radius_graph
from torch_geometric.nn.resolver import activation_resolver
from torch_geometric.nn.inits import reset, ones, zeros
from torch_geometric.utils import to_dense_batch
from typing import Optional, Callable, Any, Dict, Optional, Tuple, List
import inspect
from torch_geometric.typing import OptTensor, Adj
from torch_geometric.utils import scatter
import torch_geometric
from torch_geometric.utils import get_self_loop_attr, is_torch_sparse_tensor, to_edge_index, to_torch_coo_tensor, to_torch_csr_tensor
from torch_scatter import scatter_min, scatter_max, scatter_sum
import tqdm

def _reset_module_recursive(module: torch.nn.Module) -> None:
    for sub in module.modules():
        if hasattr(sub, 'reset_parameters'):
            sub.reset_parameters()

class PositionalEncoding(torch.nn.Module):
    def __init__(self, hidden_channels: int,
                 max_relative_feature: int = 32) -> None:
        super().__init__()
        self.max_relative_feature = max_relative_feature
        self.emb = torch.nn.Embedding(2 * max_relative_feature + 2,
                                      hidden_channels)

    def forward(self, offset, mask) -> torch.Tensor:
        d = torch.clip(offset + self.max_relative_feature, 0,
                       2 * self.max_relative_feature) * mask + (1 - mask) * (
                           2 * self.max_relative_feature + 1)  # noqa: E501
        return self.emb(d.long())
class EdgeRMSNorm(torch.nn.Module):
    def __init__(self, dim: int, eps: float = 1e-6):
        super().__init__()
        self.eps = eps
        self.weight = torch.nn.Parameter(torch.ones(dim))
    def forward(self, edge_features):
        variance = edge_features.pow(2).mean(-1, keepdim=True)
        return edge_features * torch.rsqrt(variance + self.eps) * self.weight
class EdgeSwiGLU(torch.nn.Module):
    def __init__(self, d_model: int, d_out: int, dropout_rate: float = 0.1, act:str='silu'):
        super().__init__()
        d_ffn =  int(2 * (d_model * 4 / 3)) 
        self.activation = activation_resolver(act)
        self.w_gate = torch.nn.Linear(d_model, d_ffn, bias=False)
        self.w_up = torch.nn.Linear(d_model, d_ffn, bias=False)
        self.w_down = torch.nn.Linear(d_ffn, d_out, bias=False)
        self.dropout = torch.nn.Dropout(dropout_rate)
    def forward(self, e: torch.Tensor) -> torch.Tensor:
        gated = self.activation(self.w_gate(e)) * self.w_up(e)
        out = self.w_down(gated)
        return self.dropout(out)
class EdgeUpdateBlock(torch.nn.Module):
    def __init__(self, d_model: int, dropout_rate: float = 0.1, act:str = 'silu'):
        super().__init__()
        self.norm = EdgeRMSNorm(dim=d_model)
        self.ffn = EdgeSwiGLU(d_model=d_model*3, d_out=d_model, dropout_rate=dropout_rate, act=act)
    def forward(self, h, edge_index, edge_attr) -> torch.Tensor:
        normed_edge_attr = self.norm(edge_attr)
        src, dst = edge_index[0], edge_index[1]
        h_src = h[src]  # [num_edges, 256]
        h_dst = h[dst]  # [num_edges, 256]
        cat = torch.cat([normed_edge_attr, h_src, h_dst], dim=1)
        updated_features = self.ffn(cat)
        return edge_attr +  updated_features
class MaskLabel(torch.nn.Module):
    def __init__(self, num_classes: int, out_channels: int,
                 method: str = "add"):
        super().__init__()

        self.method = method
        self.skew_power_start = 1.8
        self.skew_power_end = 4.0
        self.skew_power = 1.0
        if method not in ["add", "concat"]:
            raise ValueError(
                f"'method' must be either 'add' or 'concat' (got '{method}')")

        self.mask_token = torch.tensor(num_classes)
        self.emb = torch.nn.Embedding(num_classes + 1, out_channels)
        
        self.reset_parameters()

    def reset_parameters(self):
        r"""Resets all learnable parameters of the module."""
        self.emb.reset_parameters()
    def set_progress(self, progress: float):
        """progress in [0, 1] -- доля пройденного обучения."""
        progress = max(0.0, min(1.0, progress))
        self.skew_power = self.skew_power_start + progress * (self.skew_power_end - self.skew_power_start)
        
    def forward(self, x: torch.Tensor, y: torch.Tensor, 
                valid_mask: torch.Tensor, context_mask: torch.Tensor, 
                batch: torch.Tensor, force_full_mask:bool = False) -> torch.Tensor:

        y_to_emb, loss_mask = self._make_mask_2(y_input=y, valid_mask=valid_mask, 
                                                context_mask=context_mask, batch=batch,
                                                force_full_mask=force_full_mask)
        if self.method == "concat":
            return torch.cat([x, self.emb(y_to_emb)], dim=-1), loss_mask
        else:
            return x + self.emb(y_to_emb), loss_mask
    def _make_mask_2(self, y_input: torch.Tensor, valid_mask: torch.Tensor,
                    context_mask: torch.Tensor, batch: torch.Tensor, force_full_mask: bool = False):

        valid = valid_mask.bool()
        design_all = valid & context_mask.bool()

        y_masked = y_input.clone()
        target_mask = torch.zeros_like(design_all)
        # По графам отмечаем, где target_mask покрывает ВЕСЬ design-set этого графа
        # (это точный аналог того, что видит sample()).
        full_mask_target = torch.zeros_like(design_all)

        unique_graphs = batch.unique()
        for g in unique_graphs:
            g_mask = (batch == g)
            g_design_idx = (design_all & g_mask).nonzero(as_tuple=True)[0]

            num_g_design = g_design_idx.size(0)
            if num_g_design == 0:
                continue

            # Смещённая к высоким значениям доля маскирования:
            # u ~ U(0,1); ratio = 1 - u**skew_power концентрируется около 1
            if force_full_mask:
                num_targets = num_g_design
            elif self.training and torch.rand(1).item() < 0.2:
                num_targets = num_g_design
            else:
                u = torch.rand(1, device=y_input.device).item()
                ratio = 1.0 - u ** self.skew_power
                num_targets = max(1, min(num_g_design, round(ratio * num_g_design)))

            perm = torch.randperm(num_g_design, device=y_input.device)
            target_idx = g_design_idx[perm[:num_targets]]
            target_mask[target_idx] = True

            if num_targets == num_g_design:
                full_mask_target[target_idx] = True

        target_idx_flat = target_mask.nonzero(as_tuple=True)[0]
        num_targets_total = target_idx_flat.size(0)

        if num_targets_total > 0:
            is_full = full_mask_target[target_idx_flat]

            # --- Случай "весь граф замаскирован" (== sample()): только MASK, без утечки.
            full_idx = target_idx_flat[is_full]
            if full_idx.numel() > 0:
                y_masked[full_idx] = self.mask_token.to(y_input.dtype)

            # --- Случай частичного маскирования: обычная BERT-style коррупция 80/10/10.
            partial_idx = target_idx_flat[~is_full]
            if partial_idx.numel() > 0:
                probs = torch.rand(partial_idx.size(0), device=y_input.device)

                mask_80 = probs < 0.8
                y_masked[partial_idx[mask_80]] = self.mask_token.to(y_input.dtype)

                mask_10 = (probs >= 0.8) & (probs < 0.9)
                idx_10 = partial_idx[mask_10]
                if idx_10.numel() > 0:
                    valid_idx = valid.nonzero(as_tuple=True)[0]
                    rand_idx = valid_idx[torch.randint(0, valid_idx.size(0), (idx_10.size(0),), device=y_input.device)]
                    y_masked[idx_10] = y_input[rand_idx]
                # оставшиеся ~10% (probs >= 0.9) остаются нетронутыми — тот самый "keep true",
                # но теперь только для partial-mask случаев, не для full-mask.

        return y_masked, target_mask



def _orthogonal_matrix(dim: int) -> torch.Tensor:
    r"""Get an orthogonal matrix by applying QR decomposition."""
    # Random matrix from normal distribution
    mat = torch.randn((dim, dim))
    # QR decomposition to two orthogonal matrices
    q, _ = torch.linalg.qr(mat.cpu(), mode='reduced')
    return q.t()


def orthogonal_matrix(num_rows: int, num_cols: int) -> torch.Tensor:
    r"""Generate an orthogonal matrix with `num_rows` rows
    and `num_cols` columns.
    """
    num_full_blocks = int(num_rows / num_cols)
    blocks = []
    for _ in range(num_full_blocks):
        q = _orthogonal_matrix(num_cols)
        blocks.append(q)
    remain_rows = num_rows - num_full_blocks * num_cols
    if remain_rows > 0:
        q = _orthogonal_matrix(num_cols)
        blocks.append(q[:remain_rows])
    mat = torch.cat(blocks)
    # multiplier = torch.randn((num_rows, num_cols)).norm(dim=1)
    # scaler = torch.diag(multiplier)
    # mat = scaler @ mat
    return mat


def linear_attention(q: torch.Tensor, k: torch.Tensor, v: torch.Tensor) -> torch.Tensor:
    r"""Efficient attention mechanism from the
    `"Rethinking Attention with Performers"
    <https://arxiv.org/abs/2009.14794>`_ paper.

    .. math::
        \mathbf{\hat{D}}^{-1}(\mathbf{Q}'((\mathbf{K}')^{\top} \mathbf{V}))

    """
    D_inv = 1.0 / (q @ k.sum(dim=-2).unsqueeze(-1))
    kv = k.transpose(-2, -1) @ v
    qkv = q @ kv
    out = torch.einsum('...L,...Ld->...Ld', D_inv.squeeze(-1), qkv)
    return out


def generalized_kernel(
        x: torch.Tensor,
        mat: torch.Tensor,
        kernel: Callable = torch.nn.ReLU(),
        epsilon: float = 0.001,
) -> torch.Tensor:
    batch_size, num_heads = x.size()[:2]
    projection = mat.t().expand(batch_size, num_heads, -1, -1)
    x = x @ projection
    out = kernel(x) + epsilon
    return out


class PerformerProjection(torch.nn.Module):
    r"""The fast attention that uses a projection matrix
    from the `"Rethinking Attention with Performers"
    <https://arxiv.org/abs/2009.14794>`_ paper. This class
    projects :math:`\mathbf{Q}` and :math:`\mathbf{K}` matrices
    with specified kernel.

    Args:
        num_cols (int): Projection matrix number of columns.
        kernel (Callable, optional): Kernels for generalized attention.
            If not specified, `ReLU` kernel will be used.
            (default: :obj:`torch.nn.ReLU()`)
    """
    def __init__(self, num_cols: int, kernel: Callable = torch.nn.ReLU()):
        super().__init__()
        num_rows = int(num_cols * math.log(num_cols))
        self.num_rows = num_rows
        self.num_cols = num_cols
        # Generate an orthogonal projection matrix
        # with the shape (num_rows, num_cols)
        projection_matrix = orthogonal_matrix(self.num_rows, self.num_cols)
        self.register_buffer('projection_matrix', projection_matrix)
        assert kernel is not None
        self.kernel = kernel

    def forward(self, q: torch.Tensor, k: torch.Tensor, v: torch.Tensor, return_attn:bool=False) -> torch.Tensor:
        q = generalized_kernel(q, self.projection_matrix, self.kernel)
        k = generalized_kernel(k, self.projection_matrix, self.kernel)
        out = linear_attention(q, k, v)
        
        if return_attn:
            return out, (q, k)
        else:
            return out
class RedrawProjection_v2:
    def __init__(self, model: torch.nn.Module,
                 redraw_interval: Optional[int] = None):
        self.model = model
        self.redraw_interval = redraw_interval
        self.num_last_redraw = 0

    def redraw_projections(self):
        if not self.model.training or self.redraw_interval is None:
            return
        if self.num_last_redraw >= self.redraw_interval:
            fast_attentions = [
                module for module in self.model.modules()
                if isinstance(module, PerformerAttention)
            ]
            for fast_attention in fast_attentions:
                fast_attention.redraw_projection_matrix()
            self.num_last_redraw = 0
            print('Projection Redrawn')
            return
        self.num_last_redraw += 1


class PerformerAttention(torch.nn.Module):
    r"""The linear scaled attention mechanism from the
    `"Rethinking Attention with Performers"
    <https://arxiv.org/abs/2009.14794>`_ paper.

    Args:
        channels (int): Size of each input sample.
        heads (int, optional): Number of parallel attention heads.
        head_channels (int, optional): Size of each attention head.
            (default: :obj:`64.`)
        kernel (Callable, optional): Kernels for generalized attention.
            If not specified, `ReLU` kernel will be used.
            (default: :obj:`torch.nn.ReLU()`)
        qkv_bias (bool, optional): If specified, add bias to query, key
            and value in the self attention. (default: :obj:`False`)
        attn_out_bias (bool, optional): If specified, add bias to the
            attention output. (default: :obj:`True`)
        dropout (float, optional): Dropout probability of the final
            attention output. (default: :obj:`0.0`)

    """
    def __init__(
        self,
        channels: int,
        heads: int,
        head_channels: int = 64,
        kernel: Callable = torch.nn.ReLU(),
        qkv_bias: bool = False,
        attn_out_bias: bool = True,
        dropout: float = 0.0,
    ):
        super().__init__()
        assert channels % heads == 0
        if head_channels is None:
            head_channels = channels // heads

        self.heads = heads
        self.head_channels = head_channels
        self.kernel = kernel
        self.fast_attn = PerformerProjection(head_channels, kernel)

        inner_channels = head_channels * heads
        self.q = torch.nn.Linear(channels, inner_channels, bias=qkv_bias)
        self.k = torch.nn.Linear(channels, inner_channels, bias=qkv_bias)
        self.v = torch.nn.Linear(channels, inner_channels, bias=qkv_bias)
        self.attn_out = torch.nn.Linear(inner_channels, channels,
                                        bias=attn_out_bias)
        self.dropout = torch.nn.Dropout(dropout)

    def forward(self, x: torch.Tensor, mask: Optional[torch.Tensor] = None, return_attn:bool=False) -> torch.Tensor:
        r"""Forward pass.

        Args:
            x (torch.Tensor): Node feature tensor
                :math:`\mathbf{X} \in \mathbb{R}^{B \times N \times F}`, with
                batch-size :math:`B`, (maximum) number of nodes :math:`N` for
                each graph, and feature dimension :math:`F`.
            mask (torch.Tensor, optional): Mask matrix
                :math:`\mathbf{M} \in {\{ 0, 1 \}}^{B \times N}` indicating
                the valid nodes for each graph. (default: :obj:`None`)
        """
        B, N, *_ = x.shape
        q, k, v = self.q(x), self.k(x), self.v(x)
        # Reshape and permute q, k and v to proper shape
        # (B, N, num_heads * head_channels) to (b, num_heads, n, head_channels)
        q, k, v = map(
            lambda t: t.reshape(B, N, self.heads, self.head_channels).permute(
                0, 2, 1, 3), (q, k, v))
        if mask is not None:
            mask = mask[:, None, :, None]
            v.masked_fill_(~mask, 0.)
            q.masked_fill_(~mask, 0.)
            k.masked_fill_(~mask, 0.)
        if return_attn:
            out, attn = self.fast_attn(q, k, v, return_attn=return_attn)
            out = out.permute(0, 2, 1, 3).reshape(B, N, -1)
            out = self.attn_out(out)
            out = self.dropout(out)
            return out, attn
        else:
            out = self.fast_attn(q, k, v)
            out = out.permute(0, 2, 1, 3).reshape(B, N, -1)
            out = self.attn_out(out)
            out = self.dropout(out)
            return out

    @torch.no_grad()
    def redraw_projection_matrix(self):
        r"""As described in the paper, periodically redraw
        examples to improve overall approximation of attention.
        """
        num_rows = self.fast_attn.num_rows
        num_cols = self.fast_attn.num_cols
        projection_matrix = orthogonal_matrix(num_rows, num_cols)
        self.fast_attn.projection_matrix.copy_(projection_matrix)
        del projection_matrix

    def _reset_parameters(self):
        self.q.reset_parameters()
        self.k.reset_parameters()
        self.v.reset_parameters()
        self.attn_out.reset_parameters()
        self.redraw_projection_matrix()

    def __repr__(self) -> str:
        return (f'{self.__class__.__name__}('
                f'heads={self.heads}, '
                f'head_channels={self.head_channels} '
                f'kernel={self.kernel})')


class GraphNorm(torch.nn.Module):
    r"""Applies graph normalization over individual graphs as described in the
    `"GraphNorm: A Principled Approach to Accelerating Graph Neural Network
    Training" <https://arxiv.org/abs/2009.03294>`_ paper.

    .. math::
        \mathbf{x}^{\prime}_i = \frac{\mathbf{x} - \alpha \odot
        \textrm{E}[\mathbf{x}]}
        {\sqrt{\textrm{Var}[\mathbf{x} - \alpha \odot \textrm{E}[\mathbf{x}]]
        + \epsilon}} \odot \gamma + \beta

    where :math:`\alpha` denotes parameters that learn how much information
    to keep in the mean.

    Args:
        in_channels (int): Size of each input sample.
        eps (float, optional): A value added to the denominator for numerical
            stability. (default: :obj:`1e-5`)
        device (torch.device, optional): The device to use for the module.
            (default: :obj:`None`)
    """
    def __init__(self, in_channels: int, eps: float = 1e-5,
                 device: Optional[torch.device] = None):
        super().__init__()

        self.in_channels = in_channels
        self.eps = eps

        self.weight = torch.nn.Parameter(
            torch.empty(in_channels, device=device))
        self.bias = torch.nn.Parameter(torch.empty(in_channels, device=device))
        self.mean_scale = torch.nn.Parameter(
            torch.empty(in_channels, device=device))

        self.reset_parameters()

    def reset_parameters(self):
        r"""Resets all learnable parameters of the module."""
        ones(self.weight)
        zeros(self.bias)
        ones(self.mean_scale)

    def forward(self, x: torch.Tensor, batch: OptTensor = None,
                batch_size: Optional[int] = None, valid_mask: OptTensor = None) -> torch.Tensor:
        r"""Forward pass.

        Args:
            x (torch.Tensor): The source tensor.
            batch (torch.Tensor, optional): The batch vector
                :math:`\mathbf{b} \in {\{ 0, \ldots, B-1\}}^N`, which assigns
                each element to a specific example. (default: :obj:`None`)
            batch_size (int, optional): The number of examples :math:`B`.
                Automatically calculated if not given. (default: :obj:`None`)
        """
        if batch is None:
            batch = x.new_zeros(x.size(0), dtype=torch.long)
            batch_size = 1

        if batch_size is None:
            batch_size = int(batch.max()) + 1
        if valid_mask is None:
            mean = scatter(x, batch, 0, batch_size, reduce='mean')
            out = x - mean.index_select(0, batch) * self.mean_scale
            var = scatter(out.pow(2), batch, 0, batch_size, reduce='mean')
            std = (var + self.eps).sqrt().index_select(0, batch)
            return self.weight * out / std + self.bias
        valid_mask = valid_mask.bool()
        x_valid = x[valid_mask]
        batch_valid = batch[valid_mask]
        mean = scatter(x_valid, batch_valid, 0, batch_size, reduce='mean')
        centered_valid = x_valid - mean.index_select(0, batch_valid) * self.mean_scale
        var = scatter(centered_valid.pow(2), batch_valid, 0, batch_size, reduce='mean')
        std = (var + self.eps).sqrt()  # (batch_size, in_channels)
        mean_full = mean.index_select(0, batch)          # (N, C)
        std_full = std.index_select(0, batch)             # (N, C)
        out_full = x - mean_full * self.mean_scale
        out_full = self.weight * out_full / std_full + self.bias
        out = torch.where(valid_mask.unsqueeze(-1), out_full, x)
        return out

    def __repr__(self):
        return f'{self.__class__.__name__}({self.in_channels})'

class GPSConv_w_Performer(torch.nn.Module):
    def __init__(
        self,
        channels: int,
        conv: Optional[MessagePassing],
        heads: int = 1,
        dropout: float = 0.0,
        act: str = 'relu',
        act_kwargs: Optional[Dict[str, Any]] = None,
        norm: Optional[str] = 'batch_norm',
        norm_kwargs: Optional[Dict[str, Any]] = None,
        attn_type: str = 'performer',
        attn_kwargs: Optional[Dict[str, Any]] = None,
    ):
        super().__init__()

        self.channels = channels
        self.conv = conv
        self.heads = heads
        self.dropout = dropout
        self.attn_type = attn_type

        attn_kwargs = attn_kwargs or {}
        if attn_type == 'performer':
            self.attn = PerformerAttention(
                channels=channels,
                heads=heads,
                **attn_kwargs,
            )
        else:
            # TODO: Support BigBird
            raise ValueError(f'{attn_type} is not supported')

        self.mlp = torch.nn.Sequential(
            torch.nn.Linear(channels, channels * 2),
            activation_resolver(act, **(act_kwargs or {})),
            torch.nn.Dropout(dropout),
            torch.nn.Linear(channels * 2, channels),
            torch.nn.Dropout(dropout),
        )

        norm_kwargs = norm_kwargs or {}
        self.norm1 = GraphNorm(channels, **norm_kwargs)
        self.norm2 = GraphNorm(channels, **norm_kwargs)
        self.norm3 = GraphNorm(channels, **norm_kwargs)

        self.norm_with_batch = False
        if self.norm1 is not None:
            signature = inspect.signature(self.norm1.forward)
            self.norm_with_batch = 'batch' in signature.parameters

    def reset_parameters(self):
        r"""Resets all learnable parameters of the module."""
        if self.conv is not None:
            self.conv.reset_parameters()
        self.attn._reset_parameters()
        reset(self.mlp)
        if self.norm1 is not None:
            self.norm1.reset_parameters()
        if self.norm2 is not None:
            self.norm2.reset_parameters()
        if self.norm3 is not None:
            self.norm3.reset_parameters()

    def forward(
        self,
        x: torch.Tensor,
        edge_index: Adj,
        batch: Optional[torch.Tensor] = None,
        valid_mask: Optional[torch.Tensor] = None,
        return_global_attn:bool=False, return_local_attn:bool=False,
        zero_local:bool=False, zero_global:bool=False,
        collect_raw_stats:bool=False,
        **kwargs,
    ) -> torch.Tensor:
        r"""Runs the forward pass of the module."""
        hs = []
        if self.conv is not None:  # Local MPNN.
            if return_local_attn:
                h, local_attn = self.conv(x, edge_index,return_attention_weights=True, **kwargs)
            else:
                h = self.conv(x, edge_index, **kwargs)
            local_norm=h.norm(dim=-1)
            if zero_local:
                h = torch.zeros_like(x)
            
            h = torch.nn.functional.dropout(h, p=self.dropout, training=self.training)
            h = h + x
            if self.norm1 is not None:
                if self.norm_with_batch:
                    h = self.norm1(h, batch=batch, valid_mask=valid_mask)
                else:
                    h = self.norm1(h)
            hs.append(h)

        # Global attention transformer-style model.
        h, mask = to_dense_batch(x, batch)

        dense_valid, _ = to_dense_batch(valid_mask.float(), batch)
        dense_valid = dense_valid.bool()
        attend_mask = mask & dense_valid 
        if return_global_attn:
            h, global_attn = self.attn(h, mask=attend_mask, return_attn=True)
        else:
            h = self.attn(h, mask=attend_mask)

        h = h[mask]
        global_norm = h.norm(dim=-1)
        if zero_global:
            h = torch.zeros_like(x)
        h = torch.nn.functional.dropout(h, p=self.dropout, training=self.training)
        h = h + x  # Residual connection.
        if self.norm2 is not None:
            if self.norm_with_batch:
                h = self.norm2(h, batch=batch, valid_mask=valid_mask)
            else:
                h = self.norm2(h)
        hs.append(h)

        out = sum(hs)  # Combine local and global outputs.

        out = out + self.mlp(out)
        if self.norm3 is not None:
            if self.norm_with_batch:
                out = self.norm3(out, batch=batch, valid_mask=valid_mask)
            else:
                out = self.norm3(out)

        if collect_raw_stats:
            stats = {
                    'local_norm':local_norm,      # [num_nodes]
                    'global_norm': global_norm,    # [num_nodes]
                    }
        if collect_raw_stats and return_local_attn and return_global_attn:
            return out, (global_attn, local_attn), stats
        if return_local_attn and return_global_attn:
            return out, (global_attn, local_attn)

        if return_local_attn:
            return out, local_attn

        if return_global_attn:
            return out, global_attn
        return out

    def __repr__(self) -> str:
        return (f'{self.__class__.__name__}({self.channels}, '
                f'conv={self.conv}, heads={self.heads}, '
                f'attn_type={self.attn_type})')


def attention_rollout(attn_layers, add_residual=True, edge_index=None, num_nodes=None):
    """
    attn_layers: List[Tensor[N, N]] — по одному на слой, per-layer attention
                 (глобальное или превращённое из edge-attention в плотную N x N).
    add_residual: учитывать skip-connection (стандартный трюк rollout —
                 A_hat = 0.5*A + 0.5*I перед перемножением слоёв).
    Возвращает: Tensor[N, N] — эффективное влияние source -> target
                (rollout[target, source]).
    """
    N = attn_layers[0].shape[-1]
    device = attn_layers[0].device
    result = torch.eye(N, device=device)
 
    for A in attn_layers:
        if add_residual:
            A = 0.5 * A + 0.5 * torch.eye(N, device=device)
            A = A / A.sum(dim=-1, keepdim=True).clamp_min(1e-9)
        result = A @ result
 
    return result
def edge_attn_to_dense(local_attn, edge_index, num_nodes):
    """Разреженное edge-attention -> плотная матрица N x N (для rollout)."""
    dense = torch.zeros(num_nodes, num_nodes, device=local_attn.device)
    src, dst = edge_index
    dense[dst, src] = local_attn
    # нормируем построчно (attention должен суммироваться в 1 по соседям)
    row_sum = dense.sum(dim=-1, keepdim=True).clamp_min(1e-9)
    return dense / row_sum
def combined_rollout(global_attn_layers, local_attn_layers, edge_index, num_nodes,
                      global_weight=0.5):
    """
    Если у вас global и local attention внутри слоя суммируются/конкатенируются
    перед след. слоем — комбинируем их в одну матрицу на слой и потом rollout.
    global_weight — доля вклада глобального внимания относительно локального.
    """
    combined = []
    for g, l in zip(global_attn_layers, local_attn_layers):
        l_dense = edge_attn_to_dense(l, edge_index, num_nodes)
        combined.append(global_weight * g + (1 - global_weight) * l_dense)
    return attention_rollout(combined)
def reduce_heads(t, head_dim):    
    return t.mean(dim=head_dim)

# attn_global_reduced = [reduce_heads(attn_global[k], head_dim=0) for k in attn_global.keys()]
# local_attn_reduced = [reduce_heads(la, head_dim=-1) for la in [l[1] for l in local_att]]


class GraphEncoderBlock_fixed(torch.nn.Module):
    def __init__(self, backbone_noise: float = 0.0):
        super().__init__()
        self.channels = 128
        self.augment_eps = backbone_noise
        self.radius_for_graph = 9.5
        self.max_num_neighbors = 148
        self.pre_pe_dim = 10
        self.num_positional_embedding = 16
        self.edge_dim = 600
        self.out_channels = 21
        self.num_layers = 10
        self.local_heads = 2
        self.global_heads = 4
        self.act = 'silu'
        self.attn_type = 'performer'
        self.attn_kwargs = {'dropout': 0.0}
                
        self.pe_norm_rPa = torch.nn.BatchNorm1d(self.pre_pe_dim)
        self.pe_lin_rPa = torch.nn.Linear(self.pre_pe_dim, self.channels)
        self.local_dropout = 0.0
        self.embedding = PositionalEncoding(self.num_positional_embedding)
        self.edge_emb_input_proj = torch.nn.Sequential(
                    torch.nn.Linear(self.edge_dim+self.num_positional_embedding, self.channels),
                    torch.nn.LayerNorm(self.channels),
                    torch.nn.Linear(self.channels, self.channels),
                )
        self.label_emb = MaskLabel(self.out_channels, self.channels)
        self.convs = torch.nn.ModuleList()
        self.edge_updaters = torch.nn.ModuleList()
        
        
        for _ in range(self.num_layers):
            conv = GPSConv_w_Performer(channels=self.channels, 
                                       conv=TransformerConv(in_channels=self.channels, 
                                                            out_channels=self.channels, 
                                                            heads=self.local_heads,
                                                            concat=False, 
                                                            beta=True, 
                                                            dropout=self.local_dropout, 
                                                            edge_dim=self.channels),
                                        act=self.act,
                                        heads=self.global_heads, 
                                        attn_type=self.attn_type, 
                                        attn_kwargs=self.attn_kwargs, 
                                        dropout=self.local_dropout, 
                                        norm='graph_norm')
            self.convs.append(conv)
            e_up = EdgeUpdateBlock(d_model=self.channels, dropout_rate=self.local_dropout, act=self.act)
            self.edge_updaters.append(e_up)
        self.mlp = torch.nn.Sequential(
                    torch.nn.Linear(self.channels, self.channels *4),
                    activation_resolver(self.act),
                    torch.nn.Dropout(self.local_dropout),
                    torch.nn.Linear(self.channels*4, self.channels),
                    torch.nn.Dropout(self.local_dropout),
                )
        self.classifier = torch.nn.Sequential(
                    torch.nn.Linear(self.channels, self.channels // 2 ),
                    torch.nn.ReLU(),
                    torch.nn.Linear(self.channels// 2, self.channels // 4 ),
                    torch.nn.ReLU(),
                    torch.nn.Linear(self.channels // 4, self.out_channels),
                )
        self.redraw_projection_all = RedrawProjection_v2(
                    self,
                    redraw_interval=1000)  
        
        self.reset_parameters()
    def reset_parameters(self) -> None:    
        total_params = sum(p.numel() for p in self.parameters())
        print('Total parameters:  ', total_params)
        if total_params > 30 *1e6:
            print('The model is gonna to be checkpointed')
            self.is_checkpointed = True
        else:
            self.is_checkpointed = False
        modules_to_reset = [
                    self.pe_norm_rPa,
                    self.pe_lin_rPa,
                    self.embedding,
                    self.edge_emb_input_proj,
                    self.label_emb,
                    *self.convs,
                    *self.edge_updaters,
                    # *self.decoder_layers
                    self.mlp,
                    self.classifier,
                ]
        for module in modules_to_reset:
                    _reset_module_recursive(module)


    def _get_rwpe(self, edge_index, walk_length=10):
        row, col = edge_index
        N = edge_index.max()+1
        num_edges = edge_index.shape[1]
        value = torch.ones(num_edges, device=row.device)
        value = scatter(value, row, dim_size=N, reduce='sum').clamp(min=1)[row]
        value = 1.0 / value

        if N <= 2_000:  # Dense code path for faster computation:
            adj = torch.zeros((N, N), device=row.device)
            adj[row, col] = value
            loop_index = torch.arange(N, device=row.device)
        elif torch_geometric.typing.NO_MKL:  # pragma: no cover
            adj = to_torch_coo_tensor(edge_index, value, size=(N, N))
        else:
            adj = to_torch_csr_tensor(edge_index, value, size=(N, N))

        def get_pe(out: torch.Tensor) -> torch.Tensor:
            if is_torch_sparse_tensor(out):
                return get_self_loop_attr(*to_edge_index(out), num_nodes=N)
            return out[loop_index, loop_index]
        out = adj
        pe_list = [get_pe(out)]
        for _ in range(walk_length - 1):
            out = out @ adj
            pe_list.append(get_pe(out))

        pe = torch.stack(pe_list, dim=-1)
        return pe
    def _fourier_encode_dist(self, x, num_encodings = 4, include_self = False):
        x = x.unsqueeze(-1)
        device, dtype, orig_x = x.device, x.dtype, x
        scales = 2 ** torch.arange(num_encodings, device = device, dtype = dtype)
        x = x / scales
        x = torch.cat([x.sin(), x.cos()], dim=-1)
        x = torch.cat((x, orig_x), dim = -1) if include_self else x
        return x
    def _rbf_encode_dist(self, distances, num_rbf=16, min_distance=2.0, max_distance=32.0):
        rbf_centers = torch.linspace(min_distance, max_distance, num_rbf, device=distances.device)
        rbf_widths = (max_distance / num_rbf) * torch.ones_like(rbf_centers)
        rbf_activation = torch.exp(-((distances.unsqueeze(-1) - rbf_centers) ** 2) / (2 * rbf_widths**2))
        return rbf_activation
            
    def _featurize(
        self,
        x: torch.Tensor,
        mask: torch.Tensor,
        batch: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        N, Ca, C, O = (x[:, i, :] for i in range(4))  # noqa: E741
        b = Ca - N
        c = C - Ca
        a = torch.cross(b, c, dim=-1)
        Cb = -0.58273431 * a + 0.56802827 * b - 0.54067466 * c + Ca

        valid_mask = mask.bool()
        valid_Ca = Ca[valid_mask]
        valid_batch = batch[valid_mask]

        edge_index = radius_graph(valid_Ca, r=self.radius_for_graph, max_num_neighbors=self.max_num_neighbors,
                               batch=valid_batch, loop=True)
        rwpe = self._get_rwpe(edge_index=edge_index)
        row, col = edge_index
        original_indices = torch.arange(Ca.size(0), device=x.device)[valid_mask]
        rwpe_full = torch.zeros(Ca.size(0),self.pre_pe_dim, device=Ca.device,dtype=rwpe.dtype,)
        rwpe_full[original_indices] = rwpe 

        edge_index_original = torch.stack([original_indices[row], original_indices[col]], dim=0)
        row, col = edge_index_original
        rbf_all = []
        for A, B in list(product([N, Ca, C, O, Cb], repeat=2)):
            tmp = torch.square(A[row] - B[col])
            distances = torch.sqrt(torch.sum(tmp, 1) + 1e-6)
            rbf_en = self._rbf_encode_dist(distances)
            f_en = self._fourier_encode_dist(tmp.sum(-1), include_self=False)
            rbf_en = torch.cat([rbf_en, f_en], dim=1)
            rbf_all.append(rbf_en)

        return edge_index_original, torch.cat(rbf_all, dim=-1), rwpe_full
    def forward(self, 
                pos: torch.Tensor,
                chain_seq_label: torch.Tensor,
                mask: torch.Tensor,
                chain_mask_all: torch.Tensor,
                residue_idx: torch.Tensor,
                chain_encoding_all: torch.Tensor,
                batch: torch.Tensor,
                force_full_mask:bool=False, 
                return_global_attn:bool=False, return_local_attn:bool=False, 
                zero_local:bool=False, zero_global:bool=False, collect_raw_stats:bool=False)-> torch.Tensor: 
        if self.training:
            self.redraw_projection_all.redraw_projections()
        with torch.no_grad():
            if self.augment_eps > 0:
                pos = pos + self.augment_eps * torch.randn_like(pos)

            edge_index, edge_attr, pe_rPa = self._featurize(pos, mask, batch)
        row, col = edge_index
        offset = residue_idx[col] - residue_idx[row]
        e_chains = ((chain_encoding_all[row] -
                             chain_encoding_all[col]) == 0).long()
        e_pos = self.embedding(offset, e_chains)
        x = self.pe_lin_rPa(self.pe_norm_rPa(pe_rPa))
        edge_attr = self.edge_emb_input_proj(torch.cat([edge_attr, e_pos], dim=-1))



        x, loss_mask = self.label_emb(x=x, 
                                      y=chain_seq_label, 
                                      valid_mask=mask, 
                                      context_mask=chain_mask_all, 
                                      batch=batch, 
                                      force_full_mask=force_full_mask)
        
        attn_s = []
        raw_stats = []
        for conv, e_up in zip(self.convs, self.edge_updaters):
                edge_attr = e_up(h=x, edge_index=edge_index, edge_attr=edge_attr)    
                if return_global_attn or return_local_attn:
                    if collect_raw_stats:
                        x, attn, raw_stat = conv(x=x, edge_index=edge_index, batch=batch,valid_mask=mask, edge_attr=edge_attr, return_global_attn=return_global_attn,     return_local_attn=return_local_attn, zero_global=zero_global, zero_local=zero_local, collect_raw_stats=collect_raw_stats)
                        raw_stats +=[raw_stat]
                    else:
                        x, attn = conv(x=x, edge_index=edge_index, batch=batch,valid_mask=mask, edge_attr=edge_attr, return_global_attn=return_global_attn, return_local_attn=return_local_attn, zero_global=zero_global, zero_local=zero_local, collect_raw_stats=collect_raw_stats)
                    attn_s += [attn]
                else:
                    x = conv(x=x, edge_index=edge_index, batch=batch,valid_mask=mask, edge_attr=edge_attr)
        node_emb = self.mlp(x)               # (N, channels)  <-- embeddings

        logits = self.classifier(node_emb)


        output_dict = {'logits': logits, 
                       "loss_mask": loss_mask,
                       "attn_s": attn_s,
                       "raw_stats": raw_stats}
        return output_dict
        # if return_local_attn or return_global_attn:
        #     return logits, loss_mask, attn_s
        # return torch.nn.functional.log_softmax(logits, dim=-1), loss_mask

    @torch.no_grad()
    def _single_enc_run(self, x,y_to_emb, edge_index, edge_attr, batch, mask, return_local_attn:bool=False, return_global_attn:bool=False,
                         zero_local:bool=False, zero_global:bool=False, collect_raw_stats:bool=False):
        x = x + self.label_emb.emb(y_to_emb)
        if return_global_attn or return_local_attn:
            attn_s = []
        if collect_raw_stats:
            raw_stats = []
        for conv, e_up in zip(self.convs, self.edge_updaters):
            edge_attr = e_up(h=x, edge_index=edge_index, edge_attr=edge_attr)    
            if return_global_attn or return_local_attn:
                if collect_raw_stats:
                    x, attn, raw_stat = conv(x=x, edge_index=edge_index, batch=batch,valid_mask=mask, edge_attr=edge_attr, return_global_attn=return_global_attn, return_local_attn=return_local_attn, zero_global=zero_global, zero_local=zero_local, collect_raw_stats=collect_raw_stats)    
                    raw_stats += [raw_stat]
                else:
                    x, attn = conv(x=x, edge_index=edge_index, batch=batch,valid_mask=mask, edge_attr=edge_attr, return_global_attn=return_global_attn, return_local_attn=return_local_attn, zero_global=zero_global, zero_local=zero_local)
                attn_s += [attn]
            else:
                x = conv(x=x, edge_index=edge_index, batch=batch,valid_mask=mask, edge_attr=edge_attr)
        node_emb = self.mlp(x)               # (N, channels)  <-- embeddings
        logits = self.classifier(node_emb)
        if collect_raw_stats and (return_global_attn or return_local_attn):
            return logits, attn_s, raw_stats

        if return_global_attn or return_local_attn:
            return logits, attn_s
        return logits

    @torch.no_grad()
    def sample(self,
               pos: torch.Tensor,
               chain_seq_label: torch.Tensor,
               mask: torch.Tensor,
               chain_mask_all: torch.Tensor,
               residue_idx: torch.Tensor,
               chain_encoding_all: torch.Tensor,
               batch: torch.Tensor, 
               temperature:float=0.1, 
               deterministic: bool = False, 
               chain_M_pos=None,omit_AAs_np=None, bias_AAs_np=None,omit_AA_mask=None, bias_by_res=None,
                    pssm_coef=None, pssm_bias=None, pssm_multi=None,
                    pssm_log_odds_flag=False, pssm_log_odds_mask=None,
                    pssm_bias_flag=False,
                    return_global_attn:bool=False, return_local_attn:bool=False,
                    zero_local:bool=False, zero_global:bool=False, collect_raw_stats:bool=False, 
                    progress_bar:bool=False,
                    N_to_C_direction:bool=False) -> torch.Tensor: 
        edge_index, edge_attr, pe_rPa = self._featurize(pos, mask, batch)
        row, col = edge_index
        offset = residue_idx[col] - residue_idx[row]
        e_chains = ((chain_encoding_all[row] -
                                     chain_encoding_all[col]) == 0).long()
        e_pos = self.embedding(offset, e_chains)
        x = self.pe_lin_rPa(self.pe_norm_rPa(pe_rPa))
        edge_attr = self.edge_emb_input_proj(torch.cat([edge_attr, e_pos], dim=-1))

        valid = mask.bool()
        if chain_M_pos is not None:
            design = valid & chain_mask_all.bool() & chain_M_pos.bool()
        else:
            design = valid & chain_mask_all.bool()
        
        
        unpredicted = design.clone()
        y_masked = chain_seq_label.clone()
        y_masked[unpredicted] = self.label_emb.mask_token.to(chain_seq_label.dtype)

        predicted_classes = torch.full((x.size(0),), -1, dtype=torch.long, device=x.device)
        predicted_classes
        unique_graphs = batch.unique()

        all_probs = torch.zeros((x.size(0), 21), device=pos.device, dtype=torch.float32)

        # --- omit/bias по аминокислотам, как в оригинале (глобальные, не per-residue) ---
        if omit_AAs_np is not None:
            constant = torch.tensor(omit_AAs_np, device=pos.device, dtype=torch.float32)
        else:
            constant = torch.zeros(21, device=pos.device, dtype=torch.float32)
        if bias_AAs_np is not None:
            constant_bias = torch.tensor(bias_AAs_np, device=pos.device, dtype=torch.float32)
        else:
            constant_bias = torch.zeros(21, device=pos.device, dtype=torch.float32)

        omit_AA_mask_flag = omit_AA_mask is not None
        B = int(batch.max().item()) + 1
        if isinstance(temperature, (list, tuple)):
            num_temps = len(temperature)
            temp_tensor = torch.tensor([float(t) for t in temperature], device=pos.device)
            graph_ids = torch.arange(B, device=pos.device)
            group_size = (B + num_temps - 1) // num_temps
            temp_idx_per_graph = torch.clamp(graph_ids // group_size, max=num_temps - 1)
            temp_per_graph = temp_tensor[temp_idx_per_graph]
            temp_per_node = temp_per_graph[batch].unsqueeze(-1)  # (N, 1)
        else:
            temp_per_node = torch.full((x.size(0), 1), float(temperature), device=pos.device)

        
        
        heat_map_list_local = []
        heat_map_list_global = []
        heat_map_list_comb = []
        final_local_attn = []
        final_global_attn = []
        attn_global_steps = []
        attn_local_steps = []
        num_nodes = x.size(0)
        
        raw_stats =[]
        still_unpridicted = []
        if progress_bar:
            from tqdm.auto import tqdm
            t_prog = tqdm(desc='Residues sampling', position=0, total=num_nodes)
        while unpredicted.any():
            if return_global_attn or return_local_attn:
                if collect_raw_stats:
                    logits, att2, raw_stat = self._single_enc_run(x.clone(),
                                            y_masked, 
                                            edge_index, 
                                            edge_attr.clone(), 
                                            batch, mask, return_local_attn, return_global_attn,  zero_global=zero_global, zero_local=zero_local, collect_raw_stats=collect_raw_stats)
                    raw_stats += [raw_stat]
                else:
                    logits, att2 = self._single_enc_run(x.clone(),
                                                                y_masked, 
                                                                edge_index, 
                                                                edge_attr.clone(), 
                                                                batch, mask, return_local_attn, return_global_attn,  zero_global=zero_global, zero_local=zero_local, collect_raw_stats=collect_raw_stats)
                att = [a[0] for a in att2]
                local_att = [a[-1] for a in att2]
                # attn_global: dict {layer_idx: Tensor (H, N, N)}
                num_heads = 4
                attn_global = {}
                for i, at in enumerate(att):
                    q_proj, k_proj = at
                    mean_head = []
                    head_attn_scores = []
                    for head in range(num_heads):
                        attn_scores_head =q_proj[0][head] @ k_proj[0][head].T #at[0][head]
                        den = (q_proj[0][head] @ k_proj[0][head].sum(axis=0, keepdims=True).T)
                        attn_scores_head = attn_scores_head / (den + 1e-12)
                        head_attn_scores += [attn_scores_head]
                    attn_global[i] = torch.stack(head_attn_scores, dim=0)  # (H, N, N)
                la = {}
                for i, at in enumerate(local_att):
                    edge_weights = at
                    la[i] = edge_weights

                attn_global_steps.append(attn_global)
                attn_local_steps.append(la)


                attn_global_reduced = [reduce_heads(attn_global[k], head_dim=0) for k in attn_global.keys()]
                local_attn_reduced = [reduce_heads(la, head_dim=-1) for la in [l[1] for l in local_att]]
                final_local_attn += [edge_attn_to_dense(local_attn_reduced[-1], edge_index, num_nodes).cpu().numpy()]
                final_global_attn += [attn_global_reduced[-1].cpu().numpy()]


                rollout = combined_rollout(attn_global_reduced, local_attn_reduced, local_att[0][0], num_nodes, global_weight=0.0)
                heat_map_list_local += [rollout.cpu().numpy()]
                heat_map_list_global += [combined_rollout(attn_global_reduced, local_attn_reduced, local_att[0][0], num_nodes, global_weight=1.0).cpu().numpy()]
                heat_map_list_comb += [combined_rollout(attn_global_reduced, local_attn_reduced, local_att[0][0], num_nodes, global_weight=0.5).cpu().numpy()]
            else:
                logits = self._single_enc_run(x.clone(),
                                          y_masked, 
                                          edge_index, 
                                          edge_attr.clone(), 
                                          batch, mask)
            logits = logits / temp_per_node
            
            probs = torch.nn.functional.softmax(
                        logits - constant[None, :] * 1e8 + constant_bias[None, :] / temp_per_node
                        + (bias_by_res / temp_per_node if bias_by_res is not None else 0.0),
                        dim=-1,
                    )
            # --- pssm-mixing, как в оригинале ---
            if pssm_bias_flag and pssm_coef is not None and pssm_bias is not None:
                probs = (1 - pssm_multi * pssm_coef[:, None]) * probs + pssm_multi * pssm_coef[:, None] * pssm_bias

            if pssm_log_odds_flag and pssm_log_odds_mask is not None:
                probs_masked = probs * pssm_log_odds_mask
                probs_masked = probs_masked + probs * 0.001
                probs = probs_masked / probs_masked.sum(dim=-1, keepdim=True)

            if omit_AA_mask_flag:
                probs_masked = probs * (1.0 - omit_AA_mask)
                probs = probs_masked / probs_masked.sum(dim=-1, keepdim=True)
            # --------------------------------------
            
            if deterministic:
                sampled_preds = probs.argmax(-1)
            else:
                sampled_preds = torch.multinomial(probs, num_samples=1).squeeze(-1)

            nodes_to_fix = []
            for g in unique_graphs:
                g_unpredicted = unpredicted & (batch == g)
                if not g_unpredicted.any():
                    continue  
                g_indices = g_unpredicted.nonzero(as_tuple=True)[0]

                if deterministic or N_to_C_direction:
                    node_idx = g_indices[0]
                else:
                    rand_local_idx = torch.randint(0, g_indices.size(0), (1,)).item()
                    node_idx = g_indices[rand_local_idx]

                nodes_to_fix.append(node_idx)
            
            nodes_to_fix = torch.tensor(nodes_to_fix, device=x.device, dtype=torch.long)
            chosen_classes = sampled_preds[nodes_to_fix]
            predicted_classes[nodes_to_fix] = chosen_classes
            y_masked[nodes_to_fix] = chosen_classes
            unpredicted[nodes_to_fix] = False
            still_unpridicted += [unpredicted.clone()]
            
            if progress_bar:
                t_prog.update(1)
            
        output_dict = {"S": y_masked, "probs": all_probs, "design": design,
                       "heat_map_list_local": heat_map_list_local,
                       "heat_map_list_global": heat_map_list_global,
                       "heat_map_list_comb": heat_map_list_comb,
                       "final_local_attn": final_local_attn,
                       "final_global_attn": final_global_attn,
                       "raw_stats": raw_stats,
                       "still_unpridicted":still_unpridicted, 
                       "attn_local_steps":attn_local_steps,
                       "attn_global_steps":attn_global_steps}
                        
        return output_dict

    @torch.no_grad()
    def sample_vector(self,
               pos: torch.Tensor,
               chain_seq_label: torch.Tensor,
               mask: torch.Tensor,
               chain_mask_all: torch.Tensor,
               residue_idx: torch.Tensor,
               chain_encoding_all: torch.Tensor,
               batch: torch.Tensor, 
               temperature:float=0.1, 
               deterministic: bool = False, 
               chain_M_pos=None,omit_AAs_np=None, bias_AAs_np=None,omit_AA_mask=None, bias_by_res=None,
                    pssm_coef=None, pssm_bias=None, pssm_multi=None,
                    pssm_log_odds_flag=False, pssm_log_odds_mask=None,
                    pssm_bias_flag=False,
                    return_global_attn:bool=False, return_local_attn:bool=False,
                    zero_local:bool=False, zero_global:bool=False, collect_raw_stats:bool=False) -> torch.Tensor: 
        edge_index, edge_attr, pe_rPa = self._featurize(pos, mask, batch)
        row, col = edge_index
        offset = residue_idx[col] - residue_idx[row]
        e_chains = ((chain_encoding_all[row] -
                                     chain_encoding_all[col]) == 0).long()
        e_pos = self.embedding(offset, e_chains)
        x = self.pe_lin_rPa(self.pe_norm_rPa(pe_rPa))
        edge_attr = self.edge_emb_input_proj(torch.cat([edge_attr, e_pos], dim=-1))

        valid = mask.bool()
        if chain_M_pos is not None:
            design = valid & chain_mask_all.bool() & chain_M_pos.bool()
        else:
            design = valid & chain_mask_all.bool()
        
        
        unpredicted = design.clone()
        y_masked = chain_seq_label.clone()
        y_masked[unpredicted] = self.label_emb.mask_token.to(chain_seq_label.dtype)
        B = int(batch.max().item()) + 1
        N_total = x.size(0)
        predicted_classes = torch.full((N_total,), -1, dtype=torch.long, device=x.device)
        design_counts = scatter_sum(design.to(torch.float), batch, dim=0, dim_size=B)
        max_iters = int(design_counts.max().item())
        batch_size = B
        ones = torch.ones_like(batch, dtype=x.dtype)
        num_nodes = torch.zeros(batch_size, device=x.device, dtype=x.dtype)
        max_num_nodes = int(num_nodes.scatter_add(0, batch, ones).max())

        all_probs = torch.zeros((N_total, 21), device=pos.device, dtype=torch.float32)

        # --- omit/bias по аминокислотам, как в оригинале (глобальные, не per-residue) ---
        if omit_AAs_np is not None:
            constant = torch.tensor(omit_AAs_np, device=pos.device, dtype=torch.float32)
        else:
            constant = torch.zeros(21, device=pos.device, dtype=torch.float32)
        if bias_AAs_np is not None:
            constant_bias = torch.tensor(bias_AAs_np, device=pos.device, dtype=torch.float32)
        else:
            constant_bias = torch.zeros(21, device=pos.device, dtype=torch.float32)

        omit_AA_mask_flag = omit_AA_mask is not None
        
        if isinstance(temperature, (list, tuple)):
            num_temps = len(temperature)
            temp_tensor = torch.tensor([float(t) for t in temperature], device=pos.device)
            graph_ids = torch.arange(B, device=pos.device)
            group_size = (B + num_temps - 1) // num_temps
            temp_idx_per_graph = torch.clamp(graph_ids // group_size, max=num_temps - 1)
            temp_per_graph = temp_tensor[temp_idx_per_graph]
            temp_per_node = temp_per_graph[batch].unsqueeze(-1)  # (N, 1)
        else:
            temp_per_node = torch.full((x.size(0), 1), float(temperature), device=pos.device)

        
        
        heat_map_list_local = []
        heat_map_list_global = []
        heat_map_list_comb = []
        final_local_attn = []
        final_global_attn = []
        num_nodes = x.size(0)
        
        raw_stats =[]
        still_unpridicted = []
        
        # while unpredicted.any():
        for _ in range(max_iters):
            if return_global_attn or return_local_attn:
                if collect_raw_stats:
                    logits, att2, raw_stat = self._single_enc_run(x.clone(),
                                            y_masked, 
                                            edge_index, 
                                            edge_attr.clone(), 
                                            batch, mask, return_local_attn, return_global_attn,  zero_global=zero_global, zero_local=zero_local, collect_raw_stats=collect_raw_stats)
                    raw_stats += [raw_stat]
                else:
                    logits, att2 = self._single_enc_run(x.clone(),
                                                                y_masked, 
                                                                edge_index, 
                                                                edge_attr.clone(), 
                                                                batch, mask, return_local_attn, return_global_attn,  zero_global=zero_global, zero_local=zero_local, collect_raw_stats=collect_raw_stats)
                att = [a[0] for a in att2]
                local_att = [a[-1] for a in att2]
                # attn_global: dict {layer_idx: Tensor (H, N, N)}
                num_heads = 4
                attn_global = {}
                for i, at in enumerate(att):
                    q_proj, k_proj = at
                    mean_head = []
                    head_attn_scores = []
                    for head in range(num_heads):
                        attn_scores_head =q_proj[0][head] @ k_proj[0][head].T #at[0][head]
                        den = (q_proj[0][head] @ k_proj[0][head].sum(axis=0, keepdims=True).T)
                        attn_scores_head = attn_scores_head / (den + 1e-12)
                        head_attn_scores += [attn_scores_head]
                    attn_global[i] = torch.stack(head_attn_scores, dim=0)  # (H, N, N)
                la = {}
                for i, at in enumerate(local_att):
                    edge_weights = at
                    la[i] = edge_weights
                attn_global_reduced = [reduce_heads(attn_global[k], head_dim=0) for k in attn_global.keys()]
                local_attn_reduced = [reduce_heads(la, head_dim=-1) for la in [l[1] for l in local_att]]
                final_local_attn += [edge_attn_to_dense(local_attn_reduced[-1], edge_index, num_nodes).cpu().numpy()]
                final_global_attn += [attn_global_reduced[-1].cpu().numpy()]


                rollout = combined_rollout(attn_global_reduced, local_attn_reduced, local_att[0][0], num_nodes, global_weight=0.0)
                heat_map_list_local += [rollout.cpu().numpy()]
                heat_map_list_global += [combined_rollout(attn_global_reduced, local_attn_reduced, local_att[0][0], num_nodes, global_weight=1.0).cpu().numpy()]
                heat_map_list_comb += [combined_rollout(attn_global_reduced, local_attn_reduced, local_att[0][0], num_nodes, global_weight=0.5).cpu().numpy()]
            else:
                logits = self._single_enc_run(x.clone(),
                                          y_masked, 
                                          edge_index, 
                                          edge_attr.clone(), 
                                          batch, mask)
            logits = logits / temp_per_node
            
            probs = torch.nn.functional.softmax(
                        logits - constant[None, :] * 1e8 + constant_bias[None, :] / temp_per_node
                        + (bias_by_res / temp_per_node if bias_by_res is not None else 0.0),
                        dim=-1,
                    )
            # --- pssm-mixing, как в оригинале ---
            if pssm_bias_flag and pssm_coef is not None and pssm_bias is not None:
                probs = (1 - pssm_multi * pssm_coef[:, None]) * probs + pssm_multi * pssm_coef[:, None] * pssm_bias

            if pssm_log_odds_flag and pssm_log_odds_mask is not None:
                probs_masked = probs * pssm_log_odds_mask
                probs_masked = probs_masked + probs * 0.001
                probs = probs_masked / probs_masked.sum(dim=-1, keepdim=True)

            if omit_AA_mask_flag:
                probs_masked = probs * (1.0 - omit_AA_mask)
                probs = probs_masked / probs_masked.sum(dim=-1, keepdim=True)
            # --------------------------------------
            
            if deterministic:
                sampled_preds = probs.argmax(-1)
                order = torch.arange(N_total, device=x.device, dtype=torch.long)
                masked_order = torch.where(unpredicted, order, torch.full_like(order, 10**9))
                first_per_graph, _ = scatter_min(masked_order, batch, dim=0, dim_size=B)
                chosen = (unpredicted & (order == first_per_graph[batch]))
            else:
                sampled_preds = torch.multinomial(probs, num_samples=1).squeeze(-1)
                key = torch.rand(N_total, device=x.device)
                key = torch.where(unpredicted, key, torch.full_like(key, -1.0))
                key_max_per_graph, _ = scatter_max(key, batch, dim=0, dim_size=B)
                key_max_full = key_max_per_graph[batch]
                chosen = unpredicted & (key >= key_max_full)

            # nodes_to_fix = []
            # for g in unique_graphs:
            #     g_unpredicted = unpredicted & (batch == g)
            #     if not g_unpredicted.any():
            #         continue  
            #     g_indices = g_unpredicted.nonzero(as_tuple=True)[0]

            #     if deterministic:
            #         node_idx = g_indices[0]
            #     else:
            #         rand_local_idx = torch.randint(0, g_indices.size(0), (1,)).item()
            #         node_idx = g_indices[rand_local_idx]

            #     nodes_to_fix.append(node_idx)
            
            predicted_classes = torch.where(chosen, sampled_preds, predicted_classes)
            all_probs = torch.where(chosen.unsqueeze(-1), probs, all_probs)
            y_masked = torch.where(chosen, sampled_preds, y_masked)
            unpredicted = unpredicted & (~chosen)
            still_unpridicted += [unpredicted.clone()]
            # print(torch.argmax(chosen.to(torch.int)), predicted_classes, sampled_preds)
            # import sys
            # sys.exit()
            #all_probs = torch.where(nodes_to_fix.unsqueeze(-1), probs, all_probs)
            

        output_dict = {"S": y_masked, "probs": all_probs, "design": design,
                       "heat_map_list_local": heat_map_list_local,
                       "heat_map_list_global": heat_map_list_global,
                       "heat_map_list_comb": heat_map_list_comb,
                       "final_local_attn": final_local_attn,
                       "final_global_attn": final_global_attn,
                       "raw_stats": raw_stats,
                       "still_unpridicted":still_unpridicted}
        
        # if collect_raw_stats and (return_local_attn or return_global_attn):
        #     return output_dict, heat_map_list_local, heat_map_list_global, heat_map_list_comb, final_local_attn, final_global_attn, raw_stats
        # if return_local_attn or return_global_attn:
        #     return output_dict, heat_map_list_local, heat_map_list_global, heat_map_list_comb, final_local_attn, final_global_attn
        return output_dict









